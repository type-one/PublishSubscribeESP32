#pragma once

#include <gtest/gtest.h>

#include <map>
#include <memory>
#include <string>
#include <thread>
#include <type_traits>
#include <unordered_map>

#include "sync_dictionary.hpp"


template <typename T>
class SyncDictionaryTest : public ::testing::Test
{
protected:
    std::unique_ptr<tools::sync_dictionary<int, T>> dict_int_key;
    std::unique_ptr<tools::sync_dictionary<std::string, T>> dict_string_key;

    void SetUp() override
    {
        dict_int_key = std::make_unique<tools::sync_dictionary<int, T>>();
        dict_string_key = std::make_unique<tools::sync_dictionary<std::string, T>>();
    }

    void TearDown() override
    {
        dict_int_key.reset();
        dict_string_key.reset();
    }
};

using MyTypes = ::testing::Types<int, float, double, char, std::string>;
TYPED_TEST_SUITE(SyncDictionaryTest, MyTypes);

TYPED_TEST(SyncDictionaryTest, AddAndFindIntKey)
{
    this->dict_int_key->add(1, static_cast<TypeParam>(1));
    this->dict_int_key->add(2, static_cast<TypeParam>(2));

    EXPECT_TRUE(this->dict_int_key->find(1).has_value());
    EXPECT_EQ(this->dict_int_key->find(1).value(), static_cast<TypeParam>(1));
    EXPECT_TRUE(this->dict_int_key->find(2).has_value());
    EXPECT_EQ(this->dict_int_key->find(2).value(), static_cast<TypeParam>(2));
    EXPECT_FALSE(this->dict_int_key->find(3).has_value());
}

TYPED_TEST(SyncDictionaryTest, AddAndFindStringKey)
{
    this->dict_string_key->add("one", static_cast<TypeParam>(1));
    this->dict_string_key->add("two", static_cast<TypeParam>(2));

    EXPECT_TRUE(this->dict_string_key->find("one").has_value());
    EXPECT_EQ(this->dict_string_key->find("one").value(), static_cast<TypeParam>(1));
    EXPECT_TRUE(this->dict_string_key->find("two").has_value());
    EXPECT_EQ(this->dict_string_key->find("two").value(), static_cast<TypeParam>(2));
    EXPECT_FALSE(this->dict_string_key->find("three").has_value());
}

TYPED_TEST(SyncDictionaryTest, RemoveIntKey)
{
    this->dict_int_key->add(1, static_cast<TypeParam>(1));
    this->dict_int_key->add(2, static_cast<TypeParam>(2));
    this->dict_int_key->remove(1);

    EXPECT_FALSE(this->dict_int_key->find(1).has_value());
    EXPECT_TRUE(this->dict_int_key->find(2).has_value());
}

TYPED_TEST(SyncDictionaryTest, RemoveStringKey)
{
    this->dict_string_key->add("one", static_cast<TypeParam>(1));
    this->dict_string_key->add("two", static_cast<TypeParam>(2));
    this->dict_string_key->remove("one");

    EXPECT_FALSE(this->dict_string_key->find("one").has_value());
    EXPECT_TRUE(this->dict_string_key->find("two").has_value());
}

TYPED_TEST(SyncDictionaryTest, AddCollectionIntKey)
{
    std::map<int, TypeParam> collection = { { 1, static_cast<TypeParam>(1) }, { 2, static_cast<TypeParam>(2) } };
    this->dict_int_key->add_collection(collection);

    EXPECT_TRUE(this->dict_int_key->find(1).has_value());
    EXPECT_EQ(this->dict_int_key->find(1).value(), static_cast<TypeParam>(1));
    EXPECT_TRUE(this->dict_int_key->find(2).has_value());
    EXPECT_EQ(this->dict_int_key->find(2).value(), static_cast<TypeParam>(2));
}

TYPED_TEST(SyncDictionaryTest, AddCollectionStringKey)
{
    std::map<std::string, TypeParam> collection
        = { { "one", static_cast<TypeParam>(1) }, { "two", static_cast<TypeParam>(2) } };
    this->dict_string_key->add_collection(collection);

    EXPECT_TRUE(this->dict_string_key->find("one").has_value());
    EXPECT_EQ(this->dict_string_key->find("one").value(), static_cast<TypeParam>(1));
    EXPECT_TRUE(this->dict_string_key->find("two").has_value());
    EXPECT_EQ(this->dict_string_key->find("two").value(), static_cast<TypeParam>(2));
}

TYPED_TEST(SyncDictionaryTest, GetCollectionIntKey)
{
    this->dict_int_key->add(1, static_cast<TypeParam>(1));
    this->dict_int_key->add(2, static_cast<TypeParam>(2));

    auto collection = this->dict_int_key->get_collection();
    EXPECT_EQ(collection.size(), 2);
    EXPECT_EQ(collection[1], static_cast<TypeParam>(1));
    EXPECT_EQ(collection[2], static_cast<TypeParam>(2));
}

TYPED_TEST(SyncDictionaryTest, GetCollectionStringKey)
{
    this->dict_string_key->add("one", static_cast<TypeParam>(1));
    this->dict_string_key->add("two", static_cast<TypeParam>(2));

    auto collection = this->dict_string_key->get_collection();
    EXPECT_EQ(collection.size(), 2);
    EXPECT_EQ(collection["one"], static_cast<TypeParam>(1));
    EXPECT_EQ(collection["two"], static_cast<TypeParam>(2));
}

TYPED_TEST(SyncDictionaryTest, EmptyAndSizeIntKey)
{
    EXPECT_TRUE(this->dict_int_key->empty());
    EXPECT_EQ(this->dict_int_key->size(), 0);

    this->dict_int_key->add(1, static_cast<TypeParam>(1));
    EXPECT_FALSE(this->dict_int_key->empty());
    EXPECT_EQ(this->dict_int_key->size(), 1);
}

TYPED_TEST(SyncDictionaryTest, EmptyAndSizeStringKey)
{
    EXPECT_TRUE(this->dict_string_key->empty());
    EXPECT_EQ(this->dict_string_key->size(), 0);

    this->dict_string_key->add("one", static_cast<TypeParam>(1));
    EXPECT_FALSE(this->dict_string_key->empty());
    EXPECT_EQ(this->dict_string_key->size(), 1);
}

TYPED_TEST(SyncDictionaryTest, ClearIntKey)
{
    this->dict_int_key->add(1, static_cast<TypeParam>(1));
    this->dict_int_key->add(2, static_cast<TypeParam>(2));
    this->dict_int_key->clear();

    EXPECT_TRUE(this->dict_int_key->empty());
    EXPECT_EQ(this->dict_int_key->size(), 0);
}

TYPED_TEST(SyncDictionaryTest, ClearStringKey)
{
    this->dict_string_key->add("one", static_cast<TypeParam>(1));
    this->dict_string_key->add("two", static_cast<TypeParam>(2));
    this->dict_string_key->clear();

    EXPECT_TRUE(this->dict_string_key->empty());
    EXPECT_EQ(this->dict_string_key->size(), 0);
}

TYPED_TEST(SyncDictionaryTest, AddDuplicateKeyIntKey)
{
    this->dict_int_key->add(1, static_cast<TypeParam>(1));
    this->dict_int_key->add(1, static_cast<TypeParam>(2));

    EXPECT_TRUE(this->dict_int_key->find(1).has_value());
    EXPECT_EQ(this->dict_int_key->find(1).value(), static_cast<TypeParam>(2));
}

TYPED_TEST(SyncDictionaryTest, AddDuplicateKeyStringKey)
{
    this->dict_string_key->add("one", static_cast<TypeParam>(1));
    this->dict_string_key->add("one", static_cast<TypeParam>(2));

    EXPECT_TRUE(this->dict_string_key->find("one").has_value());
    EXPECT_EQ(this->dict_string_key->find("one").value(), static_cast<TypeParam>(2));
}

TYPED_TEST(SyncDictionaryTest, AddUnorderedCollectionIntKey)
{
    std::unordered_map<int, TypeParam> collection
        = { { 1, static_cast<TypeParam>(1) }, { 2, static_cast<TypeParam>(2) } };
    this->dict_int_key->add_collection(collection);

    EXPECT_TRUE(this->dict_int_key->find(1).has_value());
    EXPECT_EQ(this->dict_int_key->find(1).value(), static_cast<TypeParam>(1));
    EXPECT_TRUE(this->dict_int_key->find(2).has_value());
    EXPECT_EQ(this->dict_int_key->find(2).value(), static_cast<TypeParam>(2));
}

TYPED_TEST(SyncDictionaryTest, AddUnorderedCollectionStringKey)
{
    std::unordered_map<std::string, TypeParam> collection
        = { { "one", static_cast<TypeParam>(1) }, { "two", static_cast<TypeParam>(2) } };
    this->dict_string_key->add_collection(collection);

    EXPECT_TRUE(this->dict_string_key->find("one").has_value());
    EXPECT_EQ(this->dict_string_key->find("one").value(), static_cast<TypeParam>(1));
    EXPECT_TRUE(this->dict_string_key->find("two").has_value());
    EXPECT_EQ(this->dict_string_key->find("two").value(), static_cast<TypeParam>(2));
}


TYPED_TEST(SyncDictionaryTest, ConcurrentAddAndFindIntKey)
{
    std::thread t1(
        [this]()
        {
            for (int i = 0; i < 100; ++i)
            {
                this->dict_int_key->add(i, static_cast<TypeParam>(i));
            }
        });

    std::thread t2(
        [this]()
        {
            for (int i = 0; i < 100; ++i)
            {
                EXPECT_TRUE(this->dict_int_key->find(i).has_value());
            }
        });

    t1.join();
    t2.join();
}

TYPED_TEST(SyncDictionaryTest, ConcurrentAddAndRemoveIntKey)
{
    std::thread t1(
        [this]()
        {
            for (int i = 0; i < 100; ++i)
            {
                this->dict_int_key->add(i, static_cast<TypeParam>(i));
            }
        });

    std::thread t2(
        [this]()
        {
            for (int i = 0; i < 100; ++i)
            {
                this->dict_int_key->remove(i);
            }
        });

    t1.join();
    t2.join();

    EXPECT_TRUE(this->dict_int_key->empty());
}

TYPED_TEST(SyncDictionaryTest, ConcurrentAddAndClearIntKey)
{
    std::thread t1(
        [this]()
        {
            for (int i = 0; i < 100; ++i)
            {
                this->dict_int_key->add(i, static_cast<TypeParam>(i));
            }
        });

    std::thread t2([this]() { this->dict_int_key->clear(); });

    t1.join();
    t2.join();

    EXPECT_TRUE(this->dict_int_key->empty());
}

TYPED_TEST(SyncDictionaryTest, ConcurrentAddAndGetCollectionIntKey)
{
    std::thread t1(
        [this]()
        {
            for (int i = 0; i < 100; ++i)
            {
                this->dict_int_key->add(i, static_cast<TypeParam>(i));
            }
        });

    std::thread t2(
        [this]()
        {
            auto collection = this->dict_int_key->get_collection();
            EXPECT_EQ(collection.size(), 100);
        });

    t1.join();
    t2.join();
}

TYPED_TEST(SyncDictionaryTest, ConcurrentAddAndSizeIntKey)
{
    std::thread t1(
        [this]()
        {
            for (int i = 0; i < 100; ++i)
            {
                this->dict_int_key->add(i, static_cast<TypeParam>(i));
            }
        });

    std::thread t2([this]() { EXPECT_EQ(this->dict_int_key->size(), 100); });

    t1.join();
    t2.join();
}

TYPED_TEST(SyncDictionaryTest, ConcurrentAddAndEmptyIntKey)
{
    std::thread t1(
        [this]()
        {
            for (int i = 0; i < 100; ++i)
            {
                this->dict_int_key->add(i, static_cast<TypeParam>(i));
            }
        });

    std::thread t2([this]() { EXPECT_FALSE(this->dict_int_key->empty()); });

    t1.join();
    t2.join();
}

TYPED_TEST(SyncDictionaryTest, ConcurrentAddCollectionAndFindIntKey)
{
    std::map<int, TypeParam> collection;
    for (int i = 0; i < 100; ++i)
    {
        collection[i] = static_cast<TypeParam>(i);
    }

    std::thread t1([this, &collection]() { this->dict_int_key->add_collection(collection); });

    std::thread t2(
        [this]()
        {
            for (int i = 0; i < 100; ++i)
            {
                EXPECT_TRUE(this->dict_int_key->find(i).has_value());
            }
        });

    t1.join();
    t2.join();
}

TYPED_TEST(SyncDictionaryTest, ConcurrentAddUnorderedCollectionAndFindIntKey)
{
    std::unordered_map<int, TypeParam> collection;
    for (int i = 0; i < 100; ++i)
    {
        collection[i] = static_cast<TypeParam>(i);
    }

    std::thread t1([this, &collection]() { this->dict_int_key->add_collection(collection); });

    std::thread t2(
        [this]()
        {
            for (int i = 0; i < 100; ++i)
            {
                EXPECT_TRUE(this->dict_int_key->find(i).has_value());
            }
        });

    t1.join();
    t2.join();
}
