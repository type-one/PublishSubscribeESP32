#include <gtest/gtest.h>

#include <exception>
#include <memory>
#include <string>

#include "cjsonpp/cjsonpp.hpp"

class JSONObjectTest : public ::testing::Test
{
protected:
    std::unique_ptr<cjsonpp::JSONObject> obj;

    void SetUp() override
    {
        obj = std::make_unique<cjsonpp::JSONObject>();
    }

    void TearDown() override
    {
        obj.reset();
    }
};

TEST_F(JSONObjectTest, CreateEmptyObject)
{
    EXPECT_EQ(obj->type(), cjsonpp::Object);
}

TEST_F(JSONObjectTest, CreateBooleanObject)
{
    obj = std::make_unique<cjsonpp::JSONObject>(true);
    EXPECT_EQ(obj->type(), cjsonpp::Bool);
    obj = std::make_unique<cjsonpp::JSONObject>(false);
    EXPECT_EQ(obj->type(), cjsonpp::Bool);
}

TEST_F(JSONObjectTest, CreateNumberObject)
{
    obj = std::make_unique<cjsonpp::JSONObject>(42);
    EXPECT_EQ(obj->type(), cjsonpp::Number);
    obj = std::make_unique<cjsonpp::JSONObject>(3.14);
    EXPECT_EQ(obj->type(), cjsonpp::Number);
}

TEST_F(JSONObjectTest, CreateStringObject)
{
    obj = std::make_unique<cjsonpp::JSONObject>("Hello, World!");
    EXPECT_EQ(obj->type(), cjsonpp::String);
}

TEST_F(JSONObjectTest, ParseJSONString)
{
    std::string jsonString = R"({"key": "value", "number": 42})";
    obj = std::make_unique<cjsonpp::JSONObject>(cjsonpp::parse(jsonString));
    EXPECT_EQ(obj->type(), cjsonpp::Object);
    EXPECT_TRUE(obj->has("key"));
    EXPECT_TRUE(obj->has("number"));
}

TEST_F(JSONObjectTest, SetAndRemoveObjectItem)
{
    cjsonpp::JSONObject value("test");
    obj->set("key", value);
    EXPECT_TRUE(obj->has("key"));
    obj->remove("key");
    EXPECT_FALSE(obj->has("key"));
}

TEST_F(JSONObjectTest, SetAndRemoveArrayItem)
{
    obj = std::make_unique<cjsonpp::JSONObject>(cjsonpp::arrayObject());
    cjsonpp::JSONObject value("test");
    obj->set(0, value);
    EXPECT_EQ(obj->type(), cjsonpp::Array);
    obj->remove(0);
    EXPECT_EQ(obj->size(), 0);
}

TEST_F(JSONObjectTest, SerializeAndDeserializeBoolean)
{
    obj = std::make_unique<cjsonpp::JSONObject>(true);
    std::string serialized = obj->print();
    obj = std::make_unique<cjsonpp::JSONObject>(cjsonpp::parse(serialized));
    EXPECT_EQ(obj->type(), cjsonpp::Bool);
    EXPECT_TRUE(obj->obj()->valueint);
}

TEST_F(JSONObjectTest, SerializeAndDeserializeNumber)
{
    obj = std::make_unique<cjsonpp::JSONObject>(123.456);
    std::string serialized = obj->print();
    obj = std::make_unique<cjsonpp::JSONObject>(cjsonpp::parse(serialized));
    EXPECT_EQ(obj->type(), cjsonpp::Number);
    EXPECT_DOUBLE_EQ(obj->obj()->valuedouble, 123.456);
}

TEST_F(JSONObjectTest, SerializeAndDeserializeString)
{
    obj = std::make_unique<cjsonpp::JSONObject>("Test String");
    std::string serialized = obj->print();
    obj = std::make_unique<cjsonpp::JSONObject>(cjsonpp::parse(serialized));
    EXPECT_EQ(obj->type(), cjsonpp::String);
    EXPECT_STREQ(obj->obj()->valuestring, "Test String");
}

TEST_F(JSONObjectTest, CreateAndCheckNullObject)
{
    obj = std::make_unique<cjsonpp::JSONObject>(cjsonpp::nullObject());
    EXPECT_EQ(obj->type(), cjsonpp::Null);
}

TEST_F(JSONObjectTest, CreateAndCheckArrayObject)
{
    obj = std::make_unique<cjsonpp::JSONObject>(cjsonpp::arrayObject());
    EXPECT_EQ(obj->type(), cjsonpp::Array);
}

TEST_F(JSONObjectTest, ParseAndCheckNestedJSON)
{
    std::string jsonString = R"({"outer": {"inner": {"key": "value"}}})";
    obj = std::make_unique<cjsonpp::JSONObject>(cjsonpp::parse(jsonString));
    EXPECT_EQ(obj->type(), cjsonpp::Object);
    EXPECT_TRUE(obj->has("outer"));
    cjsonpp::JSONObject outer = obj->get("outer");
    EXPECT_TRUE(outer.has("inner"));
    cjsonpp::JSONObject inner = outer.get("inner");
    EXPECT_TRUE(inner.has("key"));
    EXPECT_EQ(inner.get("key").type(), cjsonpp::String);
    EXPECT_STREQ(inner.get("key").obj()->valuestring, "value");
}

TEST_F(JSONObjectTest, ParseAndCheckArrayInJSON)
{
    std::string jsonString = R"({"array": [1, 2, 3, 4, 5]})";
    obj = std::make_unique<cjsonpp::JSONObject>(cjsonpp::parse(jsonString));
    EXPECT_EQ(obj->type(), cjsonpp::Object);
    EXPECT_TRUE(obj->has("array"));
    cjsonpp::JSONObject array = obj->get("array");
    EXPECT_EQ(array.type(), cjsonpp::Array);
    EXPECT_EQ(array.size(), 5);
    for (int i = 0; i < 5; ++i)
    {
        EXPECT_EQ(array.get(i).type(), cjsonpp::Number);
        EXPECT_EQ(array.get(i).obj()->valueint, i + 1);
    }
}

TEST_F(JSONObjectTest, SetAndGetNestedObject)
{
    cjsonpp::JSONObject inner("inner_value");
    cjsonpp::JSONObject outer(cjsonpp::Object);
    outer.set("inner_key", inner);
    obj->set("outer_key", outer);
    EXPECT_TRUE(obj->has("outer_key"));
    cjsonpp::JSONObject retrievedOuter = obj->get("outer_key");
    EXPECT_TRUE(retrievedOuter.has("inner_key"));
    cjsonpp::JSONObject retrievedInner = retrievedOuter.get("inner_key");
    EXPECT_EQ(retrievedInner.type(), cjsonpp::String);
    EXPECT_STREQ(retrievedInner.obj()->valuestring, "inner_value");
}

TEST_F(JSONObjectTest, SerializeAndDeserializeNestedObject)
{
    cjsonpp::JSONObject inner("inner_value");
    cjsonpp::JSONObject outer(cjsonpp::Object);
    outer.set("inner_key", inner);
    obj->set("outer_key", outer);
    std::string serialized = obj->print();
    obj = std::make_unique<cjsonpp::JSONObject>(cjsonpp::parse(serialized));
    EXPECT_TRUE(obj->has("outer_key"));
    cjsonpp::JSONObject retrievedOuter = obj->get("outer_key");
    EXPECT_TRUE(retrievedOuter.has("inner_key"));
    cjsonpp::JSONObject retrievedInner = retrievedOuter.get("inner_key");
    EXPECT_EQ(retrievedInner.type(), cjsonpp::String);
    EXPECT_STREQ(retrievedInner.obj()->valuestring, "inner_value");
}

TEST_F(JSONObjectTest, ParseInvalidJSONString)
{
    std::string invalidJsonString = R"({"key": "value", "number": 42)";
    EXPECT_THROW(
        {
            try
            {
                obj = std::make_unique<cjsonpp::JSONObject>(cjsonpp::parse(invalidJsonString));
            }
            catch (const std::exception& e)
            {
                EXPECT_STREQ(e.what(), "Parse error");
                throw;
            }
        },
        std::exception);
}

TEST_F(JSONObjectTest, RemoveNonExistentObjectItem)
{
    EXPECT_THROW(
        {
            try
            {
                obj->remove("nonexistent");
            }
            catch (const std::exception& e)
            {
                EXPECT_STREQ(e.what(), "No such item");
                throw;
            }
        },
        std::exception);
}

TEST_F(JSONObjectTest, RemoveNonExistentArrayItem)
{
    obj = std::make_unique<cjsonpp::JSONObject>(cjsonpp::arrayObject());
    EXPECT_THROW(
        {
            try
            {
                obj->remove(0);
            }
            catch (const std::exception& e)
            {
                EXPECT_STREQ(e.what(), "No such item");
                throw;
            }
        },
        std::exception);
}

TEST_F(JSONObjectTest, SetInvalidTypeInObject)
{
    obj = std::make_unique<cjsonpp::JSONObject>(cjsonpp::arrayObject());
    cjsonpp::JSONObject value("test");
    EXPECT_THROW(
        {
            try
            {
                obj->set("key", value);
            }
            catch (const std::exception& e)
            {
                EXPECT_STREQ(e.what(), "Not an object type");
                throw;
            }
        },
        std::exception);
}

TEST_F(JSONObjectTest, SetInvalidTypeInArray)
{
    obj = std::make_unique<cjsonpp::JSONObject>();
    cjsonpp::JSONObject value("test");
    EXPECT_THROW(
        {
            try
            {
                obj->set(0, value);
            }
            catch (const std::exception& e)
            {
                EXPECT_STREQ(e.what(), "Not an array type");
                throw;
            }
        },
        std::exception);
}
