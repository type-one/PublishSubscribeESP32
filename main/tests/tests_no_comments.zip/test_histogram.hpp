#pragma once

#include <gtest/gtest.h>

#include <memory>

#include "histogram.hpp"

template <typename T>
class HistogramTest : public ::testing::Test
{
protected:
    void SetUp() override
    {
        hist = std::make_unique<tools::histogram<TypeParam>>();
    }

    void TearDown() override
    {
        hist.reset();
    }

    std::unique_ptr<tools::histogram<TypeParam>> hist;
};
;

using MyTypes = ::testing::Types<float, double>;
TYPED_TEST_SUITE(HistogramTest, MyTypes);

TYPED_TEST(HistogramTest, AddAndTop)
{
    this->hist->add(static_cast<TypeParam>(5));
    this->hist->add(static_cast<TypeParam>(3));
    this->hist->add(static_cast<TypeParam>(5));
    EXPECT_FLOAT_EQ(this->hist->top(), static_cast<TypeParam>(5));
    EXPECT_EQ(this->hist->total_count(), 3);
    EXPECT_EQ(this->hist->top_occurence(), 2);
}

TYPED_TEST(HistogramTest, Average)
{
    this->hist->add(static_cast<TypeParam>(5));
    this->hist->add(static_cast<TypeParam>(3));
    this->hist->add(static_cast<TypeParam>(5));
    this->hist->add(static_cast<TypeParam>(7));
    this->hist->add(static_cast<TypeParam>(7));
    this->hist->add(static_cast<TypeParam>(7));
    EXPECT_FLOAT_EQ(this->hist->average(), static_cast<TypeParam>(6));
}

TYPED_TEST(HistogramTest, Variance)
{
    this->hist->add(static_cast<TypeParam>(5));
    this->hist->add(static_cast<TypeParam>(3));
    this->hist->add(static_cast<TypeParam>(5));
    this->hist->add(static_cast<TypeParam>(7));
    this->hist->add(static_cast<TypeParam>(7));
    this->hist->add(static_cast<TypeParam>(7));
    TypeParam avg = this->hist->average();
    EXPECT_FLOAT_EQ(this->hist->variance(avg), static_cast<TypeParam>(2));
}

TYPED_TEST(HistogramTest, Median)
{
    this->hist->add(static_cast<TypeParam>(5));
    this->hist->add(static_cast<TypeParam>(3));
    this->hist->add(static_cast<TypeParam>(5));
    this->hist->add(static_cast<TypeParam>(7));
    this->hist->add(static_cast<TypeParam>(7));
    this->hist->add(static_cast<TypeParam>(7));
    EXPECT_FLOAT_EQ(this->hist->median(), static_cast<TypeParam>(5));
}

TYPED_TEST(HistogramTest, GaussianProbability)
{
    this->hist->add(static_cast<TypeParam>(5));
    this->hist->add(static_cast<TypeParam>(3));
    this->hist->add(static_cast<TypeParam>(5));
    this->hist->add(static_cast<TypeParam>(7));
    this->hist->add(static_cast<TypeParam>(7));
    this->hist->add(static_cast<TypeParam>(7));
    TypeParam avg = this->hist->average();
    TypeParam prob = this->hist->gaussian_probability(static_cast<TypeParam>(5), avg, this->hist->variance(avg));
    EXPECT_GT(prob, static_cast<TypeParam>(0.0));
}

TYPED_TEST(HistogramTest, EmptyHistogram)
{
    EXPECT_EQ(this->hist->total_count(), 0);
    EXPECT_EQ(this->hist->top_occurence(), 0);
    EXPECT_FLOAT_EQ(this->hist->average(), static_cast<TypeParam>(0));
    EXPECT_FLOAT_EQ(this->hist->variance(static_cast<TypeParam>(0)), static_cast<TypeParam>(0));
    EXPECT_FLOAT_EQ(this->hist->median(), static_cast<TypeParam>(0));
}
