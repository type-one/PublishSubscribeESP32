#pragma once

#include <gtest/gtest.h>

#include <memory>
#include <string>

#include "ring_vector.hpp"

template <typename T>
class RingVectorTest : public ::testing::Test
{
protected:
    void SetUp() override
    {
        rv = std::make_unique<tools::ring_vector<T>>(5);
    }

    void TearDown() override
    {
        rv.reset();
    }

    std::unique_ptr<tools::ring_vector<T>> rv;
};

using MyTypes = ::testing::Types<int, float, double, char, std::string>;
TYPED_TEST_SUITE(RingVectorTest, MyTypes);

TYPED_TEST(RingVectorTest, TestOperatorBrackets)
{
    this->rv->push(static_cast<TypeParam>(1));
    this->rv->push(static_cast<TypeParam>(2));
    this->rv->push(static_cast<TypeParam>(3));
    this->rv->push(static_cast<TypeParam>(4));
    this->rv->push(static_cast<TypeParam>(5));

    EXPECT_EQ((*this->rv)[0], static_cast<TypeParam>(1));
    EXPECT_EQ((*this->rv)[1], static_cast<TypeParam>(2));
    EXPECT_EQ((*this->rv)[2], static_cast<TypeParam>(3));
    EXPECT_EQ((*this->rv)[3], static_cast<TypeParam>(4));
    EXPECT_EQ((*this->rv)[4], static_cast<TypeParam>(5));

    this->rv->pop();
    this->rv->push(static_cast<TypeParam>(6));

    EXPECT_EQ((*this->rv)[0], static_cast<TypeParam>(2));
    EXPECT_EQ((*this->rv)[1], static_cast<TypeParam>(3));
    EXPECT_EQ((*this->rv)[2], static_cast<TypeParam>(4));
    EXPECT_EQ((*this->rv)[3], static_cast<TypeParam>(5));
    EXPECT_EQ((*this->rv)[4], static_cast<TypeParam>(6));
}

TYPED_TEST(RingVectorTest, TestPushAndPop)
{
    this->rv->push(static_cast<TypeParam>(10));
    this->rv->push(static_cast<TypeParam>(20));
    this->rv->push(static_cast<TypeParam>(30));

    EXPECT_EQ(this->rv->front(), static_cast<TypeParam>(10));
    EXPECT_EQ(this->rv->back(), static_cast<TypeParam>(30));

    this->rv->pop();
    EXPECT_EQ(this->rv->front(), static_cast<TypeParam>(20));

    this->rv->push(static_cast<TypeParam>(40));
    EXPECT_EQ(this->rv->back(), static_cast<TypeParam>(40));
}

TYPED_TEST(RingVectorTest, TestEmptyAndFull)
{
    EXPECT_TRUE(this->rv->empty());
    EXPECT_FALSE(this->rv->full());

    this->rv->push(static_cast<TypeParam>(1));
    this->rv->push(static_cast<TypeParam>(2));
    this->rv->push(static_cast<TypeParam>(3));
    this->rv->push(static_cast<TypeParam>(4));
    this->rv->push(static_cast<TypeParam>(5));

    EXPECT_FALSE(this->rv->empty());
    EXPECT_TRUE(this->rv->full());

    this->rv->pop();
    EXPECT_FALSE(this->rv->full());
}

TYPED_TEST(RingVectorTest, TestClear)
{
    this->rv->push(static_cast<TypeParam>(1));
    this->rv->push(static_cast<TypeParam>(2));
    this->rv->push(static_cast<TypeParam>(3));

    this->rv->clear();
    EXPECT_TRUE(this->rv->empty());
    EXPECT_EQ(this->rv->size(), 0);
}

TYPED_TEST(RingVectorTest, TestResize)
{
    this->rv->push(static_cast<TypeParam>(1));
    this->rv->push(static_cast<TypeParam>(2));
    this->rv->push(static_cast<TypeParam>(3));
    this->rv->push(static_cast<TypeParam>(4));
    this->rv->push(static_cast<TypeParam>(5));

    this->rv->resize(3);
    EXPECT_EQ(this->rv->size(), 3);
    EXPECT_EQ(this->rv->capacity(), 3);

    EXPECT_EQ((*this->rv)[0], static_cast<TypeParam>(3));
    EXPECT_EQ((*this->rv)[1], static_cast<TypeParam>(4));
    EXPECT_EQ((*this->rv)[2], static_cast<TypeParam>(5));

    this->rv->resize(6);
    EXPECT_EQ(this->rv->capacity(), 6);
    this->rv->push(static_cast<TypeParam>(6));
    this->rv->push(static_cast<TypeParam>(7));
    EXPECT_EQ(this->rv->size(), 5);
}
