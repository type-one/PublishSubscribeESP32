
#include <gtest/gtest.h>

#include <map>
#include <memory>
#include <string>
#include <vector>

#include "bytepack.hpp"

struct Address
{
    std::string street;
    std::string city;
    int zip_code;

    bool serialize(bytepack::binary_stream<>& stream) const
    {
        return stream.write(street, city, zip_code);
    }

    bool deserialize(bytepack::binary_stream<>& stream)
    {
        return stream.read(street, city, zip_code);
    }
};

struct Person
{
    std::string name;
    int age;
    Address address;

    bool serialize(bytepack::binary_stream<>& stream) const
    {
        return stream.write(name, age) && address.serialize(stream);
    }

    bool deserialize(bytepack::binary_stream<>& stream)
    {
        return stream.read(name, age) && address.deserialize(stream);
    }
};

struct Company
{
    std::string name;
    std::vector<Person> employees;

    bool serialize(bytepack::binary_stream<>& stream) const
    {
        if (!stream.write(name, static_cast<uint32_t>(employees.size())))
        {
            return false;
        }
        for (const auto& employee : employees)
        {
            if (!employee.serialize(stream))
            {
                return false;
            }
        }
        return true;
    }

    bool deserialize(bytepack::binary_stream<>& stream)
    {
        uint32_t employee_count;
        if (!stream.read(name, employee_count))
        {
            return false;
        }
        employees.resize(employee_count);
        for (auto& employee : employees)
        {
            if (!employee.deserialize(stream))
            {
                return false;
            }
        }
        return true;
    }
};

struct Record
{
    Address address;
    Person person;
    Company company;

    bool serialize(bytepack::binary_stream<>& stream) const
    {
        return address.serialize(stream) && person.serialize(stream) && company.serialize(stream);
    }

    bool deserialize(bytepack::binary_stream<>& stream)
    {
        return address.deserialize(stream) && person.deserialize(stream) && company.deserialize(stream);
    }
};

class SerializationTest : public ::testing::Test
{
protected:
    std::unique_ptr<bytepack::binary_stream<>> stream;

    void SetUp() override
    {
        stream = std::make_unique<bytepack::binary_stream<>>(256);
    }

    void TearDown() override
    {
        stream.reset();
    }
};

TEST_F(SerializationTest, AddressSerialization)
{
    Address original_address { "123 Main St", "Anytown", 12345 };

    ASSERT_TRUE(original_address.serialize(*stream));

    Address deserialized_address;
    stream->reset();
    ASSERT_TRUE(deserialized_address.deserialize(*stream));

    ASSERT_EQ(original_address.street, deserialized_address.street);
    ASSERT_EQ(original_address.city, deserialized_address.city);
    ASSERT_EQ(original_address.zip_code, deserialized_address.zip_code);
}

TEST_F(SerializationTest, PersonSerialization)
{
    Address address { "123 Main St", "Anytown", 12345 };
    Person original_person { "John Doe", 30, address };

    ASSERT_TRUE(original_person.serialize(*stream));

    Person deserialized_person;
    stream->reset();
    ASSERT_TRUE(deserialized_person.deserialize(*stream));

    ASSERT_EQ(original_person.name, deserialized_person.name);
    ASSERT_EQ(original_person.age, deserialized_person.age);
    ASSERT_EQ(original_person.address.street, deserialized_person.address.street);
    ASSERT_EQ(original_person.address.city, deserialized_person.address.city);
    ASSERT_EQ(original_person.address.zip_code, deserialized_person.address.zip_code);
}

TEST_F(SerializationTest, CompanySerialization)
{
    Address address1 { "123 Main St", "Anytown", 12345 };
    Address address2 { "456 Elm St", "Othertown", 67890 };
    Person person1 { "John Doe", 30, address1 };
    Person person2 { "Jane Smith", 25, address2 };
    Company original_company { "Tech Corp", { person1, person2 } };
    stream = std::make_unique<bytepack::binary_stream<>>(512);

    ASSERT_TRUE(original_company.serialize(*stream));

    Company deserialized_company;
    stream->reset();
    ASSERT_TRUE(deserialized_company.deserialize(*stream));

    ASSERT_EQ(original_company.name, deserialized_company.name);
    ASSERT_EQ(original_company.employees.size(), deserialized_company.employees.size());
    for (size_t i = 0; i < original_company.employees.size(); ++i)
    {
        ASSERT_EQ(original_company.employees[i].name, deserialized_company.employees[i].name);
        ASSERT_EQ(original_company.employees[i].age, deserialized_company.employees[i].age);
        ASSERT_EQ(original_company.employees[i].address.street, deserialized_company.employees[i].address.street);
        ASSERT_EQ(original_company.employees[i].address.city, deserialized_company.employees[i].address.city);
        ASSERT_EQ(original_company.employees[i].address.zip_code, deserialized_company.employees[i].address.zip_code);
    }
}

TEST_F(SerializationTest, EmptyCompanySerialization)
{
    Company original_company { "Empty Corp", {} };

    ASSERT_TRUE(original_company.serialize(*stream));

    Company deserialized_company;
    stream->reset();
    ASSERT_TRUE(deserialized_company.deserialize(*stream));

    ASSERT_EQ(original_company.name, deserialized_company.name);
    ASSERT_TRUE(deserialized_company.employees.empty());
}

TEST_F(SerializationTest, LargeCompanySerialization)
{
    std::vector<Person> employees;
    for (int i = 0; i < 100; ++i)
    {
        employees.push_back(
            { "Employee " + std::to_string(i), 20 + i, { "Street " + std::to_string(i), "City", 10000 + i } });
    }
    Company original_company { "Large Corp", employees };
    stream = std::make_unique<bytepack::binary_stream<>>(4096);

    ASSERT_TRUE(original_company.serialize(*stream));

    Company deserialized_company;
    stream->reset();
    ASSERT_TRUE(deserialized_company.deserialize(*stream));

    ASSERT_EQ(original_company.name, deserialized_company.name);
    ASSERT_EQ(original_company.employees.size(), deserialized_company.employees.size());
    for (size_t i = 0; i < original_company.employees.size(); ++i)
    {
        ASSERT_EQ(original_company.employees[i].name, deserialized_company.employees[i].name);
        ASSERT_EQ(original_company.employees[i].age, deserialized_company.employees[i].age);
        ASSERT_EQ(original_company.employees[i].address.street, deserialized_company.employees[i].address.street);
        ASSERT_EQ(original_company.employees[i].address.city, deserialized_company.employees[i].address.city);
        ASSERT_EQ(original_company.employees[i].address.zip_code, deserialized_company.employees[i].address.zip_code);
    }
}

TEST_F(SerializationTest, RecordSerialization)
{
    Address address { "123 Main St", "Anytown", 12345 };
    Person person { "John Doe", 30, address };
    Company company { "Tech Corp", { person } };
    Record original_record { address, person, company };

    ASSERT_TRUE(original_record.serialize(*stream));

    Record deserialized_record;
    stream->reset();
    ASSERT_TRUE(deserialized_record.deserialize(*stream));

    ASSERT_EQ(original_record.address.street, deserialized_record.address.street);
    ASSERT_EQ(original_record.address.city, deserialized_record.address.city);
    ASSERT_EQ(original_record.address.zip_code, deserialized_record.address.zip_code);
    ASSERT_EQ(original_record.person.name, deserialized_record.person.name);
    ASSERT_EQ(original_record.person.age, deserialized_record.person.age);
    ASSERT_EQ(original_record.person.address.street, deserialized_record.person.address.street);
    ASSERT_EQ(original_record.person.address.city, deserialized_record.person.address.city);
    ASSERT_EQ(original_record.person.address.zip_code, deserialized_record.person.address.zip_code);
    ASSERT_EQ(original_record.company.name, deserialized_record.company.name);
    ASSERT_EQ(original_record.company.employees.size(), deserialized_record.company.employees.size());
    for (size_t i = 0; i < original_record.company.employees.size(); ++i)
    {
        ASSERT_EQ(original_record.company.employees[i].name, deserialized_record.company.employees[i].name);
        ASSERT_EQ(original_record.company.employees[i].age, deserialized_record.company.employees[i].age);
        ASSERT_EQ(original_record.company.employees[i].address.street,
            deserialized_record.company.employees[i].address.street);
        ASSERT_EQ(
            original_record.company.employees[i].address.city, deserialized_record.company.employees[i].address.city);
        ASSERT_EQ(original_record.company.employees[i].address.zip_code,
            deserialized_record.company.employees[i].address.zip_code);
    }
}

TEST_F(SerializationTest, MapSerialization)
{
    Address address1 { "123 Main St", "Anytown", 12345 };
    Person person1 { "John Doe", 30, address1 };
    Company company1 { "Tech Corp", { person1 } };
    Record record1 { address1, person1, company1 };

    Address address2 { "456 Elm St", "Othertown", 67890 };
    Person person2 { "Jane Smith", 25, address2 };
    Company company2 { "Biz Inc", { person2 } };
    Record record2 { address2, person2, company2 };

    std::map<int, Record> original_map = { { 1, record1 }, { 2, record2 } };

    ASSERT_TRUE(stream->write(static_cast<uint32_t>(original_map.size())));
    for (const auto& [key, value] : original_map)
    {
        ASSERT_TRUE(stream->write(key));
        ASSERT_TRUE(value.serialize(*stream));
    }

    std::map<int, Record> deserialized_map;
    stream->reset();
    uint32_t map_size;
    ASSERT_TRUE(stream->read(map_size));
    for (uint32_t i = 0; i < map_size; ++i)
    {
        int key;
        Record value;
        ASSERT_TRUE(stream->read(key));
        ASSERT_TRUE(value.deserialize(*stream));
        deserialized_map[key] = value;
    }

    ASSERT_EQ(original_map.size(), deserialized_map.size());
    for (const auto& [key, value] : original_map)
    {
        const auto& deserialized_value = deserialized_map.at(key);
        ASSERT_EQ(value.address.street, deserialized_value.address.street);
        ASSERT_EQ(value.address.city, deserialized_value.address.city);
        ASSERT_EQ(value.address.zip_code, deserialized_value.address.zip_code);
        ASSERT_EQ(value.person.name, deserialized_value.person.name);
        ASSERT_EQ(value.person.age, deserialized_value.person.age);
        ASSERT_EQ(value.person.address.street, deserialized_value.person.address.street);
        ASSERT_EQ(value.person.address.city, deserialized_value.person.address.city);
        ASSERT_EQ(value.person.address.zip_code, deserialized_value.person.address.zip_code);
        ASSERT_EQ(value.company.name, deserialized_value.company.name);
        ASSERT_EQ(value.company.employees.size(), deserialized_value.company.employees.size());
        for (size_t i = 0; i < value.company.employees.size(); ++i)
        {
            ASSERT_EQ(value.company.employees[i].name, deserialized_value.company.employees[i].name);
            ASSERT_EQ(value.company.employees[i].age, deserialized_value.company.employees[i].age);
            ASSERT_EQ(
                value.company.employees[i].address.street, deserialized_value.company.employees[i].address.street);
            ASSERT_EQ(value.company.employees[i].address.city, deserialized_value.company.employees[i].address.city);
            ASSERT_EQ(
                value.company.employees[i].address.zip_code, deserialized_value.company.employees[i].address.zip_code);
        }
    }
}

TEST_F(SerializationTest, VectorOfRecordsSerialization)
{
    Address address1 { "123 Main St", "Anytown", 12345 };
    Person person1 { "John Doe", 30, address1 };
    Company company1 { "Tech Corp", { person1 } };
    Record record1 { address1, person1, company1 };

    Address address2 { "456 Elm St", "Othertown", 67890 };
    Person person2 { "Jane Smith", 25, address2 };
    Company company2 { "Biz Inc", { person2 } };
    Record record2 { address2, person2, company2 };

    std::vector<Record> original_vector = { record1, record2 };
    stream = std::make_unique<bytepack::binary_stream<>>(1024);

    ASSERT_TRUE(stream->write(static_cast<uint32_t>(original_vector.size())));
    for (const auto& record : original_vector)
    {
        ASSERT_TRUE(record.serialize(*stream));
    }

    std::vector<Record> deserialized_vector;
    stream->reset();
    uint32_t vector_size;
    ASSERT_TRUE(stream->read(vector_size));
    deserialized_vector.resize(vector_size);
    for (auto& record : deserialized_vector)
    {
        ASSERT_TRUE(record.deserialize(*stream));
    }

    ASSERT_EQ(original_vector.size(), deserialized_vector.size());
    for (size_t i = 0; i < original_vector.size(); ++i)
    {
        const auto& original_record = original_vector[i];
        const auto& deserialized_record = deserialized_vector[i];
        ASSERT_EQ(original_record.address.street, deserialized_record.address.street);
        ASSERT_EQ(original_record.address.city, deserialized_record.address.city);
        ASSERT_EQ(original_record.address.zip_code, deserialized_record.address.zip_code);
        ASSERT_EQ(original_record.person.name, deserialized_record.person.name);
        ASSERT_EQ(original_record.person.age, deserialized_record.person.age);
        ASSERT_EQ(original_record.person.address.street, deserialized_record.person.address.street);
        ASSERT_EQ(original_record.person.address.city, deserialized_record.person.address.city);
        ASSERT_EQ(original_record.person.address.zip_code, deserialized_record.person.address.zip_code);
        ASSERT_EQ(original_record.company.name, deserialized_record.company.name);
        ASSERT_EQ(original_record.company.employees.size(), deserialized_record.company.employees.size());
        for (size_t j = 0; j < original_record.company.employees.size(); ++j)
        {
            ASSERT_EQ(original_record.company.employees[j].name, deserialized_record.company.employees[j].name);
            ASSERT_EQ(original_record.company.employees[j].age, deserialized_record.company.employees[j].age);
            ASSERT_EQ(original_record.company.employees[j].address.street,
                deserialized_record.company.employees[j].address.street);
            ASSERT_EQ(original_record.company.employees[j].address.city,
                deserialized_record.company.employees[j].address.city);
            ASSERT_EQ(original_record.company.employees[j].address.zip_code,
                deserialized_record.company.employees[j].address.zip_code);
        }
    }
}
