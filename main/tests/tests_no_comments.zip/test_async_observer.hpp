#pragma once

#include <gtest/gtest.h>

#include <chrono>
#include <thread>

#include "async_observer.hpp"

class TestAsyncObserver : public ::testing::Test
{
protected:
    void SetUp() override
    {
        // Setup code here
    }

    void TearDown() override
    {
        // Cleanup code here
    }
};

TEST_F(TestAsyncObserver, SingleObserverSingleEvent)
{
    tools::async_observer<int, std::string> observer;
    std::thread observer_thread(
        [&observer]()
        {
            observer.wait_for_events();
            auto events = observer.pop_all_events();
            ASSERT_EQ(events.size(), 1);
            ASSERT_EQ(std::get<0>(events[0]), 1);
            ASSERT_EQ(std::get<1>(events[0]), "event1");
            ASSERT_EQ(std::get<2>(events[0]), "origin1");
        });

    observer.inform(1, "event1", "origin1");
    observer_thread.join();
}

TEST_F(TestAsyncObserver, SingleObserverMultipleEvents)
{
    tools::async_observer<int, std::string> observer;
    std::thread observer_thread(
        [&observer]()
        {
            observer.wait_for_events();
            auto events = observer.pop_all_events();
            ASSERT_EQ(events.size(), 3);
            ASSERT_EQ(std::get<0>(events[0]), 1);
            ASSERT_EQ(std::get<1>(events[0]), "event1");
            ASSERT_EQ(std::get<2>(events[0]), "origin1");
            ASSERT_EQ(std::get<0>(events[1]), 2);
            ASSERT_EQ(std::get<1>(events[1]), "event2");
            ASSERT_EQ(std::get<2>(events[1]), "origin2");
            ASSERT_EQ(std::get<0>(events[2]), 3);
            ASSERT_EQ(std::get<1>(events[2]), "event3");
            ASSERT_EQ(std::get<2>(events[2]), "origin3");
        });

    observer.inform(1, "event1", "origin1");
    observer.inform(2, "event2", "origin2");
    observer.inform(3, "event3", "origin3");
    observer_thread.join();
}

TEST_F(TestAsyncObserver, MultipleObserversSingleEvent)
{
    tools::async_observer<int, std::string> observer1;
    tools::async_observer<int, std::string> observer2;

    std::thread observer_thread1(
        [&observer1]()
        {
            observer1.wait_for_events();
            auto events = observer1.pop_all_events();
            ASSERT_EQ(events.size(), 1);
            ASSERT_EQ(std::get<0>(events[0]), 1);
            ASSERT_EQ(std::get<1>(events[0]), "event1");
            ASSERT_EQ(std::get<2>(events[0]), "origin1");
        });

    std::thread observer_thread2(
        [&observer2]()
        {
            observer2.wait_for_events();
            auto events = observer2.pop_all_events();
            ASSERT_EQ(events.size(), 1);
            ASSERT_EQ(std::get<0>(events[0]), 1);
            ASSERT_EQ(std::get<1>(events[0]), "event1");
            ASSERT_EQ(std::get<2>(events[0]), "origin1");
        });

    observer1.inform(1, "event1", "origin1");
    observer2.inform(1, "event1", "origin1");

    observer_thread1.join();
    observer_thread2.join();
}

TEST_F(TestAsyncObserver, MultipleObserversMultipleEvents)
{
    tools::async_observer<int, std::string> observer1;
    tools::async_observer<int, std::string> observer2;

    std::thread observer_thread1(
        [&observer1]()
        {
            observer1.wait_for_events();
            auto events = observer1.pop_all_events();
            ASSERT_EQ(events.size(), 2);
            ASSERT_EQ(std::get<0>(events[0]), 1);
            ASSERT_EQ(std::get<1>(events[0]), "event1");
            ASSERT_EQ(std::get<2>(events[0]), "origin1");
            ASSERT_EQ(std::get<0>(events[1]), 2);
            ASSERT_EQ(std::get<1>(events[1]), "event2");
            ASSERT_EQ(std::get<2>(events[1]), "origin2");
        });

    std::thread observer_thread2(
        [&observer2]()
        {
            observer2.wait_for_events();
            auto events = observer2.pop_all_events();
            ASSERT_EQ(events.size(), 2);
            ASSERT_EQ(std::get<0>(events[0]), 1);
            ASSERT_EQ(std::get<1>(events[0]), "event1");
            ASSERT_EQ(std::get<2>(events[0]), "origin1");
            ASSERT_EQ(std::get<0>(events[1]), 2);
            ASSERT_EQ(std::get<1>(events[1]), "event2");
            ASSERT_EQ(std::get<2>(events[1]), "origin2");
        });

    observer1.inform(1, "event1", "origin1");
    observer1.inform(2, "event2", "origin2");
    observer2.inform(1, "event1", "origin1");
    observer2.inform(2, "event2", "origin2");

    observer_thread1.join();
    observer_thread2.join();
}

TEST_F(TestAsyncObserver, MultipleObserversConcurrentEvents)
{
    tools::async_observer<int, std::string> observer1;
    tools::async_observer<int, std::string> observer2;

    std::thread observer_thread1(
        [&observer1]()
        {
            observer1.wait_for_events();
            auto events = observer1.pop_all_events();
            ASSERT_EQ(events.size(), 3);
            ASSERT_EQ(std::get<0>(events[0]), 1);
            ASSERT_EQ(std::get<1>(events[0]), "event1");
            ASSERT_EQ(std::get<2>(events[0]), "origin1");
            ASSERT_EQ(std::get<0>(events[1]), 2);
            ASSERT_EQ(std::get<1>(events[1]), "event2");
            ASSERT_EQ(std::get<2>(events[1]), "origin2");
            ASSERT_EQ(std::get<0>(events[2]), 3);
            ASSERT_EQ(std::get<1>(events[2]), "event3");
            ASSERT_EQ(std::get<2>(events[2]), "origin3");
        });

    std::thread observer_thread2(
        [&observer2]()
        {
            observer2.wait_for_events();
            auto events = observer2.pop_all_events();
            ASSERT_EQ(events.size(), 3);
            ASSERT_EQ(std::get<0>(events[0]), 1);
            ASSERT_EQ(std::get<1>(events[0]), "event1");
            ASSERT_EQ(std::get<2>(events[0]), "origin1");
            ASSERT_EQ(std::get<0>(events[1]), 2);
            ASSERT_EQ(std::get<1>(events[1]), "event2");
            ASSERT_EQ(std::get<2>(events[1]), "origin2");
            ASSERT_EQ(std::get<0>(events[2]), 3);
            ASSERT_EQ(std::get<1>(events[2]), "event3");
            ASSERT_EQ(std::get<2>(events[2]), "origin3");
        });

    std::thread publisher_thread(
        [&observer1, &observer2]()
        {
            observer1.inform(1, "event1", "origin1");
            observer1.inform(2, "event2", "origin2");
            observer1.inform(3, "event3", "origin3");
            observer2.inform(1, "event1", "origin1");
            observer2.inform(2, "event2", "origin2");
            observer2.inform(3, "event3", "origin3");
        });

    observer_thread1.join();
    observer_thread2.join();
    publisher_thread.join();
}

TEST_F(TestAsyncObserver, MultipleObserversConcurrentEventsWithTimeout)
{
    tools::async_observer<int, std::string> observer1;
    tools::async_observer<int, std::string> observer2;

    std::thread observer_thread1(
        [&observer1]()
        {
            observer1.wait_for_events(std::chrono::milliseconds(100));
            auto events = observer1.pop_all_events();
            ASSERT_EQ(events.size(), 3);
            ASSERT_EQ(std::get<0>(events[0]), 1);
            ASSERT_EQ(std::get<1>(events[0]), "event1");
            ASSERT_EQ(std::get<2>(events[0]), "origin1");
            ASSERT_EQ(std::get<0>(events[1]), 2);
            ASSERT_EQ(std::get<1>(events[1]), "event2");
            ASSERT_EQ(std::get<2>(events[1]), "origin2");
            ASSERT_EQ(std::get<0>(events[2]), 3);
            ASSERT_EQ(std::get<1>(events[2]), "event3");
            ASSERT_EQ(std::get<2>(events[2]), "origin3");
        });

    std::thread observer_thread2(
        [&observer2]()
        {
            observer2.wait_for_events(std::chrono::milliseconds(100));
            auto events = observer2.pop_all_events();
            ASSERT_EQ(events.size(), 3);
            ASSERT_EQ(std::get<0>(events[0]), 1);
            ASSERT_EQ(std::get<1>(events[0]), "event1");
            ASSERT_EQ(std::get<2>(events[0]), "origin1");
            ASSERT_EQ(std::get<0>(events[1]), 2);
            ASSERT_EQ(std::get<1>(events[1]), "event2");
            ASSERT_EQ(std::get<2>(events[1]), "origin2");
            ASSERT_EQ(std::get<0>(events[2]), 3);
            ASSERT_EQ(std::get<1>(events[2]), "event3");
            ASSERT_EQ(std::get<2>(events[2]), "origin3");
        });

    std::thread publisher_thread(
        [&observer1, &observer2]()
        {
            observer1.inform(1, "event1", "origin1");
            observer1.inform(2, "event2", "origin2");
            observer1.inform(3, "event3", "origin3");
            observer2.inform(1, "event1", "origin1");
            observer2.inform(2, "event2", "origin2");
            observer2.inform(3, "event3", "origin3");
        });

    observer_thread1.join();
    observer_thread2.join();
    publisher_thread.join();
}

TEST_F(TestAsyncObserver, DifferentSubjectsSingleEvent)
{
    tools::async_observer<int, std::string> observer1;
    tools::async_observer<int, std::string> observer2;

    std::thread observer_thread1(
        [&observer1]()
        {
            observer1.wait_for_events();
            auto events = observer1.pop_all_events();
            ASSERT_EQ(events.size(), 1);
            ASSERT_EQ(std::get<0>(events[0]), 1);
            ASSERT_EQ(std::get<1>(events[0]), "event1");
            ASSERT_EQ(std::get<2>(events[0]), "origin1");
        });

    std::thread observer_thread2(
        [&observer2]()
        {
            observer2.wait_for_events();
            auto events = observer2.pop_all_events();
            ASSERT_EQ(events.size(), 1);
            ASSERT_EQ(std::get<0>(events[0]), 2);
            ASSERT_EQ(std::get<1>(events[0]), "event2");
            ASSERT_EQ(std::get<2>(events[0]), "origin2");
        });

    observer1.inform(1, "event1", "origin1");
    observer2.inform(2, "event2", "origin2");

    observer_thread1.join();
    observer_thread2.join();
}

TEST_F(TestAsyncObserver, DifferentSubjectsMultipleEvents)
{
    tools::async_observer<int, std::string> observer1;
    tools::async_observer<int, std::string> observer2;

    std::thread observer_thread1(
        [&observer1]()
        {
            observer1.wait_for_events();
            auto events = observer1.pop_all_events();
            ASSERT_EQ(events.size(), 2);
            ASSERT_EQ(std::get<0>(events[0]), 1);
            ASSERT_EQ(std::get<1>(events[0]), "event1");
            ASSERT_EQ(std::get<2>(events[0]), "origin1");
            ASSERT_EQ(std::get<0>(events[1]), 3);
            ASSERT_EQ(std::get<1>(events[1]), "event3");
            ASSERT_EQ(std::get<2>(events[1]), "origin3");
        });

    std::thread observer_thread2(
        [&observer2]()
        {
            observer2.wait_for_events();
            auto events = observer2.pop_all_events();
            ASSERT_EQ(events.size(), 2);
            ASSERT_EQ(std::get<0>(events[0]), 2);
            ASSERT_EQ(std::get<1>(events[0]), "event2");
            ASSERT_EQ(std::get<2>(events[0]), "origin2");
            ASSERT_EQ(std::get<0>(events[1]), 4);
            ASSERT_EQ(std::get<1>(events[1]), "event4");
            ASSERT_EQ(std::get<2>(events[1]), "origin4");
        });

    observer1.inform(1, "event1", "origin1");
    observer1.inform(3, "event3", "origin3");
    observer2.inform(2, "event2", "origin2");
    observer2.inform(4, "event4", "origin4");

    observer_thread1.join();
    observer_thread2.join();
}

TEST_F(TestAsyncObserver, DifferentSubjectsConcurrentEvents)
{
    tools::async_observer<int, std::string> observer1;
    tools::async_observer<int, std::string> observer2;

    std::thread observer_thread1(
        [&observer1]()
        {
            observer1.wait_for_events();
            auto events = observer1.pop_all_events();
            ASSERT_EQ(events.size(), 3);
            ASSERT_EQ(std::get<0>(events[0]), 1);
            ASSERT_EQ(std::get<1>(events[0]), "event1");
            ASSERT_EQ(std::get<2>(events[0]), "origin1");
            ASSERT_EQ(std::get<0>(events[1]), 3);
            ASSERT_EQ(std::get<1>(events[1]), "event3");
            ASSERT_EQ(std::get<2>(events[1]), "origin3");
            ASSERT_EQ(std::get<0>(events[2]), 5);
            ASSERT_EQ(std::get<1>(events[2]), "event5");
            ASSERT_EQ(std::get<2>(events[2]), "origin5");
        });

    std::thread observer_thread2(
        [&observer2]()
        {
            observer2.wait_for_events();
            auto events = observer2.pop_all_events();
            ASSERT_EQ(events.size(), 3);
            ASSERT_EQ(std::get<0>(events[0]), 2);
            ASSERT_EQ(std::get<1>(events[0]), "event2");
            ASSERT_EQ(std::get<2>(events[0]), "origin2");
            ASSERT_EQ(std::get<0>(events[1]), 4);
            ASSERT_EQ(std::get<1>(events[1]), "event4");
            ASSERT_EQ(std::get<2>(events[1]), "origin4");
            ASSERT_EQ(std::get<0>(events[2]), 6);
            ASSERT_EQ(std::get<1>(events[2]), "event6");
            ASSERT_EQ(std::get<2>(events[2]), "origin6");
        });

    std::thread publisher_thread(
        [&observer1, &observer2]()
        {
            observer1.inform(1, "event1", "origin1");
            observer1.inform(3, "event3", "origin3");
            observer1.inform(5, "event5", "origin5");
            observer2.inform(2, "event2", "origin2");
            observer2.inform(4, "event4", "origin4");
            observer2.inform(6, "event6", "origin6");
        });

    observer_thread1.join();
    observer_thread2.join();
    publisher_thread.join();
}

TEST_F(TestAsyncObserver, DifferentSubjectsConcurrentEventsWithTimeout)
{
    tools::async_observer<int, std::string> observer1;
    tools::async_observer<int, std::string> observer2;

    std::thread observer_thread1(
        [&observer1]()
        {
            observer1.wait_for_events(std::chrono::milliseconds(100));
            auto events = observer1.pop_all_events();
            ASSERT_EQ(events.size(), 3);
            ASSERT_EQ(std::get<0>(events[0]), 1);
            ASSERT_EQ(std::get<1>(events[0]), "event1");
            ASSERT_EQ(std::get<2>(events[0]), "origin1");
            ASSERT_EQ(std::get<0>(events[1]), 3);
            ASSERT_EQ(std::get<1>(events[1]), "event3");
            ASSERT_EQ(std::get<2>(events[1]), "origin3");
            ASSERT_EQ(std::get<0>(events[2]), 5);
            ASSERT_EQ(std::get<1>(events[2]), "event5");
            ASSERT_EQ(std::get<2>(events[2]), "origin5");
        });

    std::thread observer_thread2(
        [&observer2]()
        {
            observer2.wait_for_events(std::chrono::milliseconds(100));
            auto events = observer2.pop_all_events();
            ASSERT_EQ(events.size(), 3);
            ASSERT_EQ(std::get<0>(events[0]), 2);
            ASSERT_EQ(std::get<1>(events[0]), "event2");
            ASSERT_EQ(std::get<2>(events[0]), "origin2");
            ASSERT_EQ(std::get<0>(events[1]), 4);
            ASSERT_EQ(std::get<1>(events[1]), "event4");
            ASSERT_EQ(std::get<2>(events[1]), "origin4");
            ASSERT_EQ(std::get<0>(events[2]), 6);
            ASSERT_EQ(std::get<1>(events[2]), "event6");
            ASSERT_EQ(std::get<2>(events[2]), "origin6");
        });

    std::thread publisher_thread(
        [&observer1, &observer2]()
        {
            observer1.inform(1, "event1", "origin1");
            observer1.inform(3, "event3", "origin3");
            observer1.inform(5, "event5", "origin5");
            observer2.inform(2, "event2", "origin2");
            observer2.inform(4, "event4", "origin4");
            observer2.inform(6, "event6", "origin6");
        });

    observer_thread1.join();
    observer_thread2.join();
    publisher_thread.join();
}
