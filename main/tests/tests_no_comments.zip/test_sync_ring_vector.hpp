#pragma once

#include <gtest/gtest.h>

#include <memory>
#include <string>
#include <thread>
#include <vector>

#include "sync_ring_vector.hpp"

template <typename T>
class SyncRingVectorTest : public ::testing::Test
{
protected:
    void SetUp() override
    {
        vec = std::make_unique<tools::sync_ring_vector<T>>(5);
    }

    void TearDown() override
    {
        vec.reset();
    }

    std::unique_ptr<tools::sync_ring_vector<T>> vec;
};

using TestTypes = ::testing::Types<int, float, double, char, std::string>;
TYPED_TEST_SUITE(SyncRingVectorTest, TestTypes);

TYPED_TEST(SyncRingVectorTest, PushAndSize)
{
    this->vec->push(static_cast<TypeParam>(1));
    this->vec->push(static_cast<TypeParam>(2));
    this->vec->push(static_cast<TypeParam>(3));
    EXPECT_EQ(this->vec->size(), 3);
}

TYPED_TEST(SyncRingVectorTest, FrontAndBack)
{
    this->vec->push(static_cast<TypeParam>(1));
    this->vec->push(static_cast<TypeParam>(2));
    this->vec->push(static_cast<TypeParam>(3));
    EXPECT_EQ(this->vec->front(), static_cast<TypeParam>(1));
    EXPECT_EQ(this->vec->back(), static_cast<TypeParam>(3));
}

TYPED_TEST(SyncRingVectorTest, Pop)
{
    this->vec->push(static_cast<TypeParam>(1));
    this->vec->push(static_cast<TypeParam>(2));
    this->vec->push(static_cast<TypeParam>(3));
    this->vec->pop();
    EXPECT_EQ(this->vec->size(), 2);
    EXPECT_EQ(this->vec->front(), static_cast<TypeParam>(2));
}

TYPED_TEST(SyncRingVectorTest, EmptyAndFull)
{
    this->vec->push(static_cast<TypeParam>(1));
    this->vec->push(static_cast<TypeParam>(2));
    EXPECT_FALSE(this->vec->empty());
    this->vec->push(static_cast<TypeParam>(3));
    this->vec->push(static_cast<TypeParam>(4));
    this->vec->push(static_cast<TypeParam>(5));
    EXPECT_TRUE(this->vec->full());
}

TYPED_TEST(SyncRingVectorTest, Resize)
{
    this->vec->resize(10);
    EXPECT_EQ(this->vec->capacity(), 10);
}

TYPED_TEST(SyncRingVectorTest, IsrPushAndIsrSize)
{
    this->vec->isr_push(static_cast<TypeParam>(1));
    this->vec->isr_push(static_cast<TypeParam>(2));
    this->vec->isr_push(static_cast<TypeParam>(3));
    EXPECT_EQ(this->vec->isr_size(), 3);
}

TYPED_TEST(SyncRingVectorTest, IsrFull)
{
    this->vec->isr_push(static_cast<TypeParam>(1));
    this->vec->isr_push(static_cast<TypeParam>(2));
    this->vec->isr_push(static_cast<TypeParam>(3));
    this->vec->isr_push(static_cast<TypeParam>(4));
    this->vec->isr_push(static_cast<TypeParam>(5));
    EXPECT_TRUE(this->vec->isr_full());
}

TYPED_TEST(SyncRingVectorTest, IsrResize)
{
    this->vec->isr_resize(15);
    EXPECT_EQ(this->vec->capacity(), 15);
}

TYPED_TEST(SyncRingVectorTest, MultipleProducersMultipleConsumers)
{
    auto producer = [this](int start, int end) {
        for (int i = start; i < end; ++i) {
            this->vec->push(static_cast<TypeParam>(i));
        }
    };

    auto consumer = [this](int count) {
        for (int i = 0; i < count; ++i) {
            this->vec->pop();
        }
    };

    std::thread producer1(producer, 0, 5);
    std::thread producer2(producer, 5, 10);
    std::thread consumer1(consumer, 5);
    std::thread consumer2(consumer, 5);

    producer1.join();
    producer2.join();
    consumer1.join();
    consumer2.join();

    EXPECT_TRUE(this->vec->empty());
}

TYPED_TEST(SyncRingVectorTest, SingleProducerMultipleConsumers)
{
    auto producer = [this]() {
        for (int i = 0; i < 10; ++i) {
            this->vec->push(static_cast<TypeParam>(i));
        }
    };

    auto consumer = [this](int count) {
        for (int i = 0; i < count; ++i) {
            this->vec->pop();
        }
    };

    std::thread producerThread(producer);
    std::thread consumer1(consumer, 5);
    std::thread consumer2(consumer, 5);

    producerThread.join();
    consumer1.join();
    consumer2.join();

    EXPECT_TRUE(this->vec->empty());
}

TYPED_TEST(SyncRingVectorTest, MultipleProducersSingleConsumer)
{
    auto producer = [this](int start, int end) {
        for (int i = start; i < end; ++i) {
            this->vec->push(static_cast<TypeParam>(i));
        }
    };

    auto consumer = [this](int count) {
        for (int i = 0; i < count; ++i) {
            this->vec->pop();
        }
    };

    std::thread producer1(producer, 0, 5);
    std::thread producer2(producer, 5, 10);
    std::thread consumerThread(consumer, 10);

    producer1.join();
    producer2.join();
    consumerThread.join();

    EXPECT_TRUE(this->vec->empty());
}
