#pragma once

#include <gtest/gtest.h>

#include <memory>
#include <string>
#include <thread>
#include <vector>

#include "tools/sync_ring_buffer.hpp"

template <typename T>
class SyncRingBufferTest : public ::testing::Test
{
protected:
    void SetUp() override
    {
        buffer = std::make_unique<tools::sync_ring_buffer<T, 5>>();
    }

    void TearDown() override
    {
        buffer.reset();
    }

    std::unique_ptr<tools::sync_ring_buffer<T, 5>> buffer;
};

using TestTypes = ::testing::Types<int, float, double, char, std::string>;
TYPED_TEST_SUITE(SyncRingBufferTest, TestTypes);

TYPED_TEST(SyncRingBufferTest, EmptyBuffer)
{
    ASSERT_TRUE(this->buffer->empty());
    ASSERT_FALSE(this->buffer->full());
    ASSERT_EQ(this->buffer->size(), 0);
}

TYPED_TEST(SyncRingBufferTest, PushAndFront)
{
    this->buffer->push(static_cast<TypeParam>(1));
    ASSERT_FALSE(this->buffer->empty());
    ASSERT_EQ(this->buffer->front(), static_cast<TypeParam>(1));
    ASSERT_EQ(this->buffer->size(), 1);
}

TYPED_TEST(SyncRingBufferTest, EmplaceAndBack)
{
    this->buffer->emplace(static_cast<TypeParam>(2));
    ASSERT_EQ(this->buffer->back(), static_cast<TypeParam>(2));
    ASSERT_EQ(this->buffer->size(), 1);
}

TYPED_TEST(SyncRingBufferTest, Pop)
{
    this->buffer->push(static_cast<TypeParam>(1));
    this->buffer->push(static_cast<TypeParam>(2));
    this->buffer->pop();
    ASSERT_EQ(this->buffer->front(), static_cast<TypeParam>(2));
    ASSERT_EQ(this->buffer->size(), 1);
}

TYPED_TEST(SyncRingBufferTest, FullBuffer)
{
    this->buffer->push(static_cast<TypeParam>(1));
    this->buffer->push(static_cast<TypeParam>(2));
    this->buffer->push(static_cast<TypeParam>(3));
    this->buffer->push(static_cast<TypeParam>(4));
    this->buffer->push(static_cast<TypeParam>(5));
    ASSERT_TRUE(this->buffer->full());
    ASSERT_EQ(this->buffer->size(), 5);
}

TYPED_TEST(SyncRingBufferTest, IsrPushAndIsrFull)
{
    this->buffer->isr_push(static_cast<TypeParam>(1));
    this->buffer->isr_push(static_cast<TypeParam>(2));
    this->buffer->isr_push(static_cast<TypeParam>(3));
    this->buffer->isr_push(static_cast<TypeParam>(4));
    this->buffer->isr_push(static_cast<TypeParam>(5));
    ASSERT_TRUE(this->buffer->isr_full());
    ASSERT_EQ(this->buffer->isr_size(), 5);
}

TYPED_TEST(SyncRingBufferTest, IsrEmplace)
{
    this->buffer->isr_emplace(static_cast<TypeParam>(1));
    this->buffer->isr_emplace(static_cast<TypeParam>(2));
    this->buffer->isr_emplace(static_cast<TypeParam>(3));
    this->buffer->isr_emplace(static_cast<TypeParam>(4));
    this->buffer->isr_emplace(static_cast<TypeParam>(5));
    ASSERT_EQ(this->buffer->isr_size(), 5);
}

TYPED_TEST(SyncRingBufferTest, Capacity)
{
    ASSERT_EQ(this->buffer->capacity(), 5);
}

TYPED_TEST(SyncRingBufferTest, MultipleProducersMultipleConsumers)
{
    auto producer = [this](int id)
    {
        for (int i = 0; i < 10; ++i)
        {
            this->buffer->push(static_cast<TypeParam>(id * 10 + i));
        }
    };

    auto consumer = [this]()
    {
        for (int i = 0; i < 10; ++i)
        {
            if (!this->buffer->empty())
            {
                this->buffer->pop();
            }
        }
    };

    std::thread producer1(producer, 1);
    std::thread producer2(producer, 2);
    std::thread consumer1(consumer);
    std::thread consumer2(consumer);

    producer1.join();
    producer2.join();
    consumer1.join();
    consumer2.join();

    ASSERT_TRUE(this->buffer->empty() || this->buffer->size() <= 10);
}

TYPED_TEST(SyncRingBufferTest, SingleProducerMultipleConsumers)
{
    auto producer = [this]()
    {
        for (int i = 0; i < 20; ++i)
        {
            this->buffer->push(static_cast<TypeParam>(i));
        }
    };

    auto consumer = [this]()
    {
        for (int i = 0; i < 10; ++i)
        {
            if (!this->buffer->empty())
            {
                this->buffer->pop();
            }
        }
    };

    std::thread producerThread(producer);
    std::thread consumer1(consumer);
    std::thread consumer2(consumer);

    producerThread.join();
    consumer1.join();
    consumer2.join();

    ASSERT_TRUE(this->buffer->empty());
}

TYPED_TEST(SyncRingBufferTest, MultipleProducersSingleConsumer)
{
    auto producer = [this](int id)
    {
        for (int i = 0; i < 10; ++i)
        {
            this->buffer->push(static_cast<TypeParam>(id * 10 + i));
        }
    };

    auto consumer = [this]()
    {
        for (int i = 0; i < 20; ++i)
        {
            if (!this->buffer->empty())
            {
                this->buffer->pop();
            }
        }
    };

    std::thread producer1(producer, 1);
    std::thread producer2(producer, 2);
    std::thread consumerThread(consumer);

    producer1.join();
    producer2.join();
    consumerThread.join();

    ASSERT_TRUE(this->buffer->empty());
}
