/**
 * The MIT License (MIT)
 *
 * Copyright (c) 2015 Michael Egli
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * \author    Michael Egli
 * \copyright Michael Egli
 * \date      11-Jul-2015
 *
 * \file timer_test.cpp
 *
 * Tests for cpptime component. Compile with
 *
 * ~~~
 * g++ -std=c++11 -Wall -Wextra -o test timer_test.cpp -l pthread
 * ~~~
 *
 */
#include <gtest/gtest.h>

#include "../cpptime.h"

#include <chrono>
#include <memory>
#include <thread>

using namespace std::chrono;

class TimerTest : public ::testing::Test
{
protected:
    std::unique_ptr<CppTime::Timer> timer;

    void SetUp() override
    {
        timer = std::make_unique<CppTime::Timer>();
    }

    void TearDown() override
    {
        timer.reset();
    }
};

TEST_F(TimerTest, TestStartAndStop)
{
    std::unique_ptr<CppTime::Timer> timer = std::make_unique<CppTime::Timer>();
}

TEST_F(TimerTest, TestTwoArgumentAdd)
{
    int i = 0;

    timer->add(100000, [&](CppTime::timer_id) { i = 42; });
    std::this_thread::sleep_for(milliseconds(120));
    EXPECT_EQ(i, 42);

    i = 0;
    timer->add(milliseconds(100), [&](CppTime::timer_id) { i = 43; });
    std::this_thread::sleep_for(milliseconds(120));
    EXPECT_EQ(i, 43);

    i = 0;
    timer->add(CppTime::clock::now() + milliseconds(100), [&](CppTime::timer_id) { i = 44; });
    std::this_thread::sleep_for(milliseconds(120));
    EXPECT_EQ(i, 44);
}

TEST_F(TimerTest, TestThreeArgumentAdd)
{
    size_t count = 0;

    auto id = timer->add(
        100000, [&](CppTime::timer_id) { ++count; }, 10000);
    std::this_thread::sleep_for(milliseconds(125));
    timer->remove(id);
    EXPECT_EQ(count, 3);

    count = 0;
    id = timer->add(
        milliseconds(100), [&](CppTime::timer_id) { ++count; }, microseconds(10000));
    std::this_thread::sleep_for(milliseconds(135));
    timer->remove(id);
    EXPECT_EQ(count, 4);
}

TEST_F(TimerTest, TestDeleteTimerInCallback)
{
    size_t count = 0;

    timer->add(
        milliseconds(10),
        [&](CppTime::timer_id id)
        {
            ++count;
            timer->remove(id);
        },
        milliseconds(10));
    std::this_thread::sleep_for(milliseconds(50));
    EXPECT_EQ(count, 1);

    auto id1 = timer->add(milliseconds(40), [](CppTime::timer_id) {});
    auto id2 = timer->add(milliseconds(10), [&](CppTime::timer_id id) { timer->remove(id); });
    std::this_thread::sleep_for(milliseconds(30));
    auto id3 = timer->add(microseconds(100), [](CppTime::timer_id) {});
    auto id4 = timer->add(microseconds(100), [](CppTime::timer_id) {});
    EXPECT_EQ(id3, id2);
    EXPECT_NE(id4, id1);
    EXPECT_NE(id4, id2);
    std::this_thread::sleep_for(milliseconds(20));

    id1 = timer->add(milliseconds(10), [&](CppTime::timer_id id) { timer->remove(id); });
    id2 = timer->add(milliseconds(40), [](CppTime::timer_id) {});
    std::this_thread::sleep_for(milliseconds(30));
    id3 = timer->add(microseconds(100), [](CppTime::timer_id) {});
    id4 = t->add(microseconds(100), [](CppTime::timer_id) {});
    EXPECT_EQ(id3, id1);
    EXPECT_NE(id4, id1);
    EXPECT_NE(id4, id2);
    std::this_thread::sleep_for(milliseconds(20));
}

TEST_F(TimerTest, TestTwoIdenticalTimeouts)
{
    int i = 0;
    int j = 0;
    CppTime::timestamp ts = CppTime::clock::now() + milliseconds(40);
    t->add(ts, [&](CppTime::timer_id) { i = 42; });
    t->add(ts, [&](CppTime::timer_id) { j = 43; });
    std::this_thread::sleep_for(milliseconds(50));
    EXPECT_EQ(i, 42);
    EXPECT_EQ(j, 43);
}

TEST_F(TimerTest, TestTimeoutsFromThePast)
{
    int i = 0;
    int j = 0;
    CppTime::timestamp ts1 = CppTime::clock::now() - milliseconds(10);
    CppTime::timestamp ts2 = CppTime::clock::now() - milliseconds(20);
    t->add(ts1, [&](CppTime::timer_id) { i = 42; });
    t->add(ts2, [&](CppTime::timer_id) { j = 43; });
    std::this_thread::sleep_for(microseconds(20));
    EXPECT_EQ(i, 42);
    EXPECT_EQ(j, 43);

    i = 0;
    CppTime::timestamp ts3 = CppTime::clock::now() + milliseconds(10);
    CppTime::timestamp ts4 = CppTime::clock::now() + milliseconds(20);
    t->add(ts3, [&](CppTime::timer_id) { std::this_thread::sleep_for(milliseconds(20)); });
    t->add(ts4, [&](CppTime::timer_id) { i = 42; });
    std::this_thread::sleep_for(milliseconds(50));
    EXPECT_EQ(i, 42);
}

TEST_F(TimerTest, TestOrderOfMultipleTimeouts)
{
    int i = 0;
    t->add(10000, [&](CppTime::timer_id) { i = 42; });
    t->add(20000, [&](CppTime::timer_id) { i = 43; });
    t->add(30000, [&](CppTime::timer_id) { i = 44; });
    t->add(40000, [&](CppTime::timer_id) { i = 45; });
    std::this_thread::sleep_for(milliseconds(50));
    EXPECT_EQ(i, 45);
}

TEST_F(TimerTest, TestWithMultipleTimers)
{
    int i = 0;
    std::unique_ptr<CppTime::Timer> t1 = std::make_unique<CppTime::Timer>();
    std::unique_ptr<CppTime::Timer> t2 = std::make_unique<CppTime::Timer>();

    t1->add(milliseconds(20), [&](CppTime::timer_id) { i = 42; });
    t1->add(milliseconds(40), [&](CppTime::timer_id) { i = 43; });
    std::this_thread::sleep_for(milliseconds(30));
    EXPECT_EQ(i, 42);
    std::this_thread::sleep_for(milliseconds(20));
    EXPECT_EQ(i, 43);

    auto id1 = t1->add(milliseconds(20), [&](CppTime::timer_id) { i = 42; });
    t1->add(milliseconds(40), [&](CppTime::timer_id) { i = 43; });
    std::this_thread::sleep_for(milliseconds(10));
    t1->remove(id1);
    std::this_thread::sleep_for(milliseconds(20));
    EXPECT_EQ(i, 0);
    std::this_thread::sleep_for(milliseconds(20));
    EXPECT_EQ(i, 43);
}

TEST_F(TimerTest, TestRemoveTimerId)
{
    auto id = t->add(milliseconds(20), [](CppTime::timer_id) {});
    std::this_thread::sleep_for(microseconds(10));
    auto res = t->remove(id + 1);
    EXPECT_FALSE(res);

    auto shared = std::make_shared<int>(10);
    CppTime::handler_t func = [=](CppTime::timer_id) { auto shared2 = shared; };
    id = t->add(milliseconds(20), std::move(func));
    EXPECT_EQ(shared.use_count(), 2);
    std::this_thread::sleep_for(microseconds(10));
    res = t->remove(id);
    EXPECT_TRUE(res);
    EXPECT_EQ(shared.use_count(), 1);

    shared = std::make_shared<int>(10);
    func = [=](CppTime::timer_id) { auto shared2 = shared; };
    t->add(milliseconds(20), std::move(func));
    EXPECT_EQ(shared.use_count(), 2);
    std::this_thread::sleep_for(milliseconds(30));
    EXPECT_EQ(shared.use_count(), 1);
}

TEST_F(TimerTest, PassAnArgumentToAnAction)
{
    struct PushMe
    {
        int i { 0 };
    };
    auto push_me = std::make_shared<PushMe>();
    push_me->i = 41;

    int res = 0;

    t->add(milliseconds(20), [&res, push_me](CppTime::timer_id) { res = push_me->i + 1; });

    EXPECT_EQ(res, 0);
    std::this_thread::sleep_for(milliseconds(30));
    EXPECT_EQ(res, 42);
}
