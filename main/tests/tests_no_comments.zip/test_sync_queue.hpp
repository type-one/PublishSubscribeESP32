#pragma once

#include <gtest/gtest.h>

#include <memory>
#include <string>
#include <thread>
#include <vector>

#include "sync_queue.hpp"

template <typename T>
class SyncQueueTest : public ::testing::Test
{
protected:
    void SetUp() override
    {
        // Code here will be called immediately after the constructor (right before each test).
        queue = std::make_unique<tools::sync_queue<T>>();
    }

    void TearDown() override
    {
        // Code here will be called immediately after each test (right before the destructor).
        queue.reset();
    }

    std::unique_ptr<tools::sync_queue<T>> queue;
};

using TestTypes = ::testing::Types<int, float, double, char, std::string>;
TYPED_TEST_SUITE(SyncQueueTest, TestTypes);

TYPED_TEST(SyncQueueTest, PushAndSize)
{
    this->queue->push(static_cast<TypeParam>(1));
    this->queue->push(static_cast<TypeParam>(2));
    EXPECT_EQ(this->queue->size(), 2);
}

TYPED_TEST(SyncQueueTest, FrontAndBack)
{
    this->queue->push(static_cast<TypeParam>(1));
    this->queue->push(static_cast<TypeParam>(2));
    EXPECT_EQ(this->queue->front(), static_cast<TypeParam>(1));
    EXPECT_EQ(this->queue->back(), static_cast<TypeParam>(2));
}

TYPED_TEST(SyncQueueTest, Pop)
{
    this->queue->push(static_cast<TypeParam>(1));
    this->queue->push(static_cast<TypeParam>(2));
    this->queue->pop();
    EXPECT_EQ(this->queue->size(), 1);
    EXPECT_EQ(this->queue->front(), static_cast<TypeParam>(2));
}

TYPED_TEST(SyncQueueTest, Empty)
{
    this->queue->push(static_cast<TypeParam>(1));
    this->queue->pop();
    EXPECT_TRUE(this->queue->empty());
}

TYPED_TEST(SyncQueueTest, Emplace)
{
    this->queue->emplace(static_cast<TypeParam>(3));
    EXPECT_EQ(this->queue->size(), 1);
    EXPECT_EQ(this->queue->front(), static_cast<TypeParam>(3));
}

TYPED_TEST(SyncQueueTest, IsrPushAndSize)
{
    this->queue->isr_push(static_cast<TypeParam>(4));
    EXPECT_EQ(this->queue->isr_size(), 1);
    this->queue->isr_push(static_cast<TypeParam>(5));
    EXPECT_EQ(this->queue->isr_size(), 2);
}

TYPED_TEST(SyncQueueTest, IsrEmplace)
{
    this->queue->isr_emplace(static_cast<TypeParam>(6));
    EXPECT_EQ(this->queue->isr_size(), 1);
    EXPECT_EQ(this->queue->back(), static_cast<TypeParam>(6));
}

TYPED_TEST(SyncQueueTest, MultipleOperations)
{
    this->queue->push(static_cast<TypeParam>(1));
    this->queue->push(static_cast<TypeParam>(2));
    this->queue->emplace(static_cast<TypeParam>(3));
    this->queue->isr_push(static_cast<TypeParam>(4));
    this->queue->isr_emplace(static_cast<TypeParam>(5));
    EXPECT_EQ(this->queue->size(), 5);
    EXPECT_EQ(this->queue->front(), static_cast<TypeParam>(1));
    EXPECT_EQ(this->queue->back(), static_cast<TypeParam>(5));
    this->queue->pop();
    EXPECT_EQ(this->queue->front(), static_cast<TypeParam>(2));
    this->queue->pop();
    this->queue->pop();
    this->queue->pop();
    this->queue->pop();
    EXPECT_TRUE(this->queue->empty());
}

TYPED_TEST(SyncQueueTest, MultipleProducersMultipleConsumers)
{
    const int num_producers = 4;
    const int num_consumers = 4;
    const int num_elements = 100;

    auto producer = [this, num_elements]()
    {
        for (int i = 0; i < num_elements; ++i)
        {
            this->queue->push(static_cast<TypeParam>(i));
        }
    };

    auto consumer = [this, num_elements]()
    {
        for (int i = 0; i < num_elements; ++i)
        {
            while (this->queue->empty())
            {
                std::this_thread::yield();
            }
            this->queue->pop();
        }
    };

    std::vector<std::thread> producers;
    std::vector<std::thread> consumers;

    for (int i = 0; i < num_producers; ++i)
    {
        producers.emplace_back(producer);
    }

    for (int i = 0; i < num_consumers; ++i)
    {
        consumers.emplace_back(consumer);
    }

    for (auto& producer : producers)
    {
        producer.join();
    }

    for (auto& consumer : consumers)
    {
        consumer.join();
    }

    EXPECT_TRUE(this->queue->empty());
}

TYPED_TEST(SyncQueueTest, SingleProducerMultipleConsumers)
{
    const int num_consumers = 4;
    const int num_elements = 100;

    auto producer = [this, num_elements]()
    {
        for (int i = 0; i < num_elements; ++i)
        {
            this->queue->push(static_cast<TypeParam>(i));
        }
    };

    auto consumer = [this, num_elements]()
    {
        for (int i = 0; i < num_elements / num_consumers; ++i)
        {
            while (this->queue->empty())
            {
                std::this_thread::yield();
            }
            this->queue->pop();
        }
    };

    std::thread producer_thread(producer);
    std::vector<std::thread> consumers;

    for (int i = 0; i < num_consumers; ++i)
    {
        consumers.emplace_back(consumer);
    }

    producer_thread.join();

    for (auto& consumer : consumers)
    {
        consumer.join();
    }

    EXPECT_TRUE(this->queue->empty());
}

TYPED_TEST(SyncQueueTest, MultipleProducersSingleConsumer)
{
    const int num_producers = 4;
    const int num_elements = 100;

    auto producer = [this, num_elements]()
    {
        for (int i = 0; i < num_elements; ++i)
        {
            this->queue->push(static_cast<TypeParam>(i));
        }
    };

    auto consumer = [this, num_producers, num_elements]()
    {
        for (int i = 0; i < num_producers * num_elements; ++i)
        {
            while (this->queue->empty())
            {
                std::this_thread::yield();
            }
            this->queue->pop();
        }
    };

    std::vector<std::thread> producers;
    std::thread consumer_thread(consumer);

    for (int i = 0; i < num_producers; ++i)
    {
        producers.emplace_back(producer);
    }

    for (auto& producer : producers)
    {
        producer.join();
    }

    consumer_thread.join();

    EXPECT_TRUE(this->queue->empty());
}
