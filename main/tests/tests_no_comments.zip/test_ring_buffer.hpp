#pragma once

#include <gtest/gtest.h>

#include <memory>
#include <string>

#include "ring_buffer.hpp"

template <typename T>
class RingBufferTest : public ::testing::Test
{
protected:
    void SetUp() override
    {
        buffer = std::make_unique<tools::ring_buffer<T, 5>>();
    }

    void TearDown() override
    {
        buffer.reset();
    }

    std::unique_ptr<tools::ring_buffer<T, 5>> buffer;
};

using MyTypes = ::testing::Types<int, float, double, char, std::string>;
TYPED_TEST_SUITE(RingBufferTest, MyTypes);

TYPED_TEST(RingBufferTest, PushAndPop)
{
    this->buffer->push(static_cast<TypeParam>(1));
    this->buffer->push(static_cast<TypeParam>(2));
    this->buffer->push(static_cast<TypeParam>(3));

    EXPECT_EQ(this->buffer->size(), 3);
    EXPECT_EQ(this->buffer->front(), static_cast<TypeParam>(1));
    EXPECT_EQ(this->buffer->back(), static_cast<TypeParam>(3));

    this->buffer->pop();
    EXPECT_EQ(this->buffer->size(), 2);
    EXPECT_EQ(this->buffer->front(), static_cast<TypeParam>(2));
}

TYPED_TEST(RingBufferTest, Emplace)
{
    this->buffer->emplace(static_cast<TypeParam>(1));
    this->buffer->emplace(static_cast<TypeParam>(2));
    this->buffer->emplace(static_cast<TypeParam>(3));

    EXPECT_EQ(this->buffer->size(), 3);
    EXPECT_EQ(this->buffer->front(), static_cast<TypeParam>(1));
    EXPECT_EQ(this->buffer->back(), static_cast<TypeParam>(3));
}

TYPED_TEST(RingBufferTest, Clear)
{
    this->buffer->push(static_cast<TypeParam>(1));
    this->buffer->push(static_cast<TypeParam>(2));
    this->buffer->push(static_cast<TypeParam>(3));

    this->buffer->clear();
    EXPECT_EQ(this->buffer->size(), 0);
    EXPECT_TRUE(this->buffer->empty());
}

TYPED_TEST(RingBufferTest, FullBuffer)
{
    this->buffer->push(static_cast<TypeParam>(1));
    this->buffer->push(static_cast<TypeParam>(2));
    this->buffer->push(static_cast<TypeParam>(3));
    this->buffer->push(static_cast<TypeParam>(4));
    this->buffer->push(static_cast<TypeParam>(5));

    EXPECT_TRUE(this->buffer->full());
    EXPECT_EQ(this->buffer->size(), 5);
}

TYPED_TEST(RingBufferTest, OverwriteWhenFull)
{
    this->buffer->push(static_cast<TypeParam>(1));
    this->buffer->push(static_cast<TypeParam>(2));
    this->buffer->push(static_cast<TypeParam>(3));
    this->buffer->push(static_cast<TypeParam>(4));
    this->buffer->push(static_cast<TypeParam>(5));

    this->buffer->push(static_cast<TypeParam>(6)); // This should overwrite the first element (1)

    EXPECT_EQ(this->buffer->size(), 6); // Size should be 6 because we increment size even when overwriting
    EXPECT_EQ(this->buffer->front(), static_cast<TypeParam>(2)); // The new front should be 2
    EXPECT_EQ(this->buffer->back(), static_cast<TypeParam>(6));  // The new back should be 6
}

TYPED_TEST(RingBufferTest, CopyConstructor)
{
    this->buffer->push(static_cast<TypeParam>(1));
    this->buffer->push(static_cast<TypeParam>(2));
    this->buffer->push(static_cast<TypeParam>(3));

    tools::ring_buffer<TypeParam, 5> copy_buffer(*this->buffer);

    EXPECT_EQ(copy_buffer.size(), 3);
    EXPECT_EQ(copy_buffer.front(), static_cast<TypeParam>(1));
    EXPECT_EQ(copy_buffer.back(), static_cast<TypeParam>(3));
}

TYPED_TEST(RingBufferTest, MoveConstructor)
{
    this->buffer->push(static_cast<TypeParam>(1));
    this->buffer->push(static_cast<TypeParam>(2));
    this->buffer->push(static_cast<TypeParam>(3));

    tools::ring_buffer<TypeParam, 5> move_buffer(std::move(*this->buffer));

    EXPECT_EQ(move_buffer.size(), 3);
    EXPECT_EQ(move_buffer.front(), static_cast<TypeParam>(1));
    EXPECT_EQ(move_buffer.back(), static_cast<TypeParam>(3));
}

TYPED_TEST(RingBufferTest, CopyAssignment)
{
    this->buffer->push(static_cast<TypeParam>(1));
    this->buffer->push(static_cast<TypeParam>(2));
    this->buffer->push(static_cast<TypeParam>(3));

    tools::ring_buffer<TypeParam, 5> copy_buffer;
    copy_buffer = *this->buffer;

    EXPECT_EQ(copy_buffer.size(), 3);
    EXPECT_EQ(copy_buffer.front(), static_cast<TypeParam>(1));
    EXPECT_EQ(copy_buffer.back(), static_cast<TypeParam>(3));
}

TYPED_TEST(RingBufferTest, MoveAssignment)
{
    this->buffer->push(static_cast<TypeParam>(1));
    this->buffer->push(static_cast<TypeParam>(2));
    this->buffer->push(static_cast<TypeParam>(3));

    tools::ring_buffer<TypeParam, 5> move_buffer;
    move_buffer = std::move(*this->buffer);

    EXPECT_EQ(move_buffer.size(), 3);
    EXPECT_EQ(move_buffer.front(), static_cast<TypeParam>(1));
    EXPECT_EQ(move_buffer.back(), static_cast<TypeParam>(3));
}
