#pragma once

#include <gtest/gtest.h>

#include <iostream>
#include <memory>
#include <string>
#include <thread>

#include "sync_observer.hpp"

class TestObserver : public tools::sync_observer<std::string, int>
{
public:
    void inform(const std::string& topic, const int& event, const std::string& origin) override
    {
        std::cout << "Observer informed: Topic = " << topic << ", Event = " << event << ", Origin = " << origin
                  << std::endl;
        last_topic = topic;
        last_event = event;
        last_origin = origin;
    }

    std::string last_topic;
    int last_event;
    std::string last_origin;
};

class SyncObserverTest : public ::testing::Test
{
protected:
    void SetUp() override
    {
        subject = std::make_unique<tools::sync_subject<std::string, int>>("TestSubject");
        observer = std::make_shared<TestObserver>();
    }

    void TearDown() override
    {
        subject.reset();
        observer.reset();
    }

    std::unique_ptr<tools::sync_subject<std::string, int>> subject;
    std::shared_ptr<TestObserver> observer;
};

TEST_F(SyncObserverTest, SubscribeAndPublish)
{
    subject->subscribe("TestTopic", observer);

    subject->publish("TestTopic", 42);

    ASSERT_EQ(observer->last_topic, "TestTopic");
    ASSERT_EQ(observer->last_event, 42);
    ASSERT_EQ(observer->last_origin, "TestSubject");
}

TEST_F(SyncObserverTest, Unsubscribe)
{
    subject->subscribe("TestTopic", observer);
    subject->unsubscribe("TestTopic", observer);

    subject->publish("TestTopic", 100);

    ASSERT_NE(observer->last_event, 100);
}

TEST_F(SyncObserverTest, MultipleObservers)
{
    auto observer2 = std::make_shared<TestObserver>();
    subject->subscribe("TestTopic", observer);
    subject->subscribe("TestTopic", observer2);

    subject->publish("TestTopic", 42);

    ASSERT_EQ(observer->last_topic, "TestTopic");
    ASSERT_EQ(observer->last_event, 42);
    ASSERT_EQ(observer->last_origin, "TestSubject");

    ASSERT_EQ(observer2->last_topic, "TestTopic");
    ASSERT_EQ(observer2->last_event, 42);
    ASSERT_EQ(observer2->last_origin, "TestSubject");
}

TEST_F(SyncObserverTest, MultipleTopics)
{
    subject->subscribe("Topic1", observer);

    subject->publish("Topic1", 42);
    ASSERT_EQ(observer->last_topic, "Topic1");
    ASSERT_EQ(observer->last_event, 42);

    subject->publish("Topic2", 100);
    ASSERT_NE(observer->last_topic, "Topic2");
    ASSERT_NE(observer->last_event, 100);
}

TEST_F(SyncObserverTest, ConcurrentObservers)
{
    auto observer2 = std::make_shared<TestObserver>();
    subject->subscribe("TestTopic", observer);
    subject->subscribe("TestTopic", observer2);

    std::thread t1([&]() { subject->publish("TestTopic", 42); });

    std::thread t2([&]() { subject->publish("TestTopic", 84); });

    t1.join();
    t2.join();

    ASSERT_TRUE((observer->last_event == 42 || observer->last_event == 84));
    ASSERT_TRUE((observer2->last_event == 42 || observer2->last_event == 84));
}

TEST_F(SyncObserverTest, ConcurrentSubscribeAndUnsubscribe)
{
    auto observer2 = std::make_shared<TestObserver>();

    std::thread t1(
        [&]()
        {
            for (int i = 0; i < 100; ++i)
            {
                subject->subscribe("TestTopic", observer);
                subject->unsubscribe("TestTopic", observer);
            }
        });

    std::thread t2(
        [&]()
        {
            for (int i = 0; i < 100; ++i)
            {
                subject->subscribe("TestTopic", observer2);
                subject->unsubscribe("TestTopic", observer2);
            }
        });

    t1.join();
    t2.join();

    // Ensure no deadlocks or crashes occurred
    SUCCEED();
}

TEST_F(SyncObserverTest, ConcurrentPublish)
{
    subject->subscribe("TestTopic", observer);

    std::thread t1(
        [&]()
        {
            for (int i = 0; i < 100; ++i)
            {
                subject->publish("TestTopic", i);
            }
        });

    std::thread t2(
        [&]()
        {
            for (int i = 100; i < 200; ++i)
            {
                subject->publish("TestTopic", i);
            }
        });

    t1.join();
    t2.join();

    // Ensure the last event is within the expected range
    ASSERT_TRUE(observer->last_event >= 0 && observer->last_event < 200);
}
