#pragma once

#include <gtest/gtest.h>

#include <memory>
#include <string>

#include "lock_free_ring_buffer.hpp"

#pragma once

#include <gtest/gtest.h>
#include <memory>
#include <string>
#include <thread>
#include "lock_free_ring_buffer.hpp"

template <typename T>
class LockFreeRingBufferTest : public ::testing::Test
{
protected:

    void SetUp() override
    {
        // Initialize buffer before each test
        buffer = std::make_unique<tools::lock_free_ring_buffer<T, 4>>();
    }

    void TearDown() override
    {
        // Clean up buffer after each test
        buffer.reset();
    }

    std::unique_ptr<tools::lock_free_ring_buffer<T, 4>> buffer;
};

using MyTypes = ::testing::Types<int, float, double, char, std::string>;
TYPED_TEST_SUITE(LockFreeRingBufferTest, MyTypes);

TYPED_TEST(LockFreeRingBufferTest, CapacityTest)
{
    ASSERT_EQ(this->buffer->capacity(), 16);
}

TYPED_TEST(LockFreeRingBufferTest, PushPopTest)
{
    TypeParam value;
    ASSERT_TRUE(this->buffer->push(static_cast<TypeParam>(1)));
    ASSERT_TRUE(this->buffer->push(static_cast<TypeParam>(2)));
    ASSERT_TRUE(this->buffer->push(static_cast<TypeParam>(3)));
    ASSERT_TRUE(this->buffer->push(static_cast<TypeParam>(4)));
    ASSERT_TRUE(this->buffer->push(static_cast<TypeParam>(5)));
    ASSERT_TRUE(this->buffer->push(static_cast<TypeParam>(6)));
    ASSERT_TRUE(this->buffer->push(static_cast<TypeParam>(7)));
    ASSERT_TRUE(this->buffer->push(static_cast<TypeParam>(8)));
    ASSERT_TRUE(this->buffer->push(static_cast<TypeParam>(9)));
    ASSERT_TRUE(this->buffer->push(static_cast<TypeParam>(10)));
    ASSERT_TRUE(this->buffer->push(static_cast<TypeParam>(11)));
    ASSERT_TRUE(this->buffer->push(static_cast<TypeParam>(12)));
    ASSERT_TRUE(this->buffer->push(static_cast<TypeParam>(13)));
    ASSERT_TRUE(this->buffer->push(static_cast<TypeParam>(14)));
    ASSERT_TRUE(this->buffer->push(static_cast<TypeParam>(15)));
    ASSERT_FALSE(this->buffer->push(static_cast<TypeParam>(16))); // Buffer should be full

    ASSERT_TRUE(this->buffer->pop(value));
    ASSERT_EQ(value, static_cast<TypeParam>(1));
    ASSERT_TRUE(this->buffer->pop(value));
    ASSERT_EQ(value, static_cast<TypeParam>(2));
    ASSERT_TRUE(this->buffer->pop(value));
    ASSERT_EQ(value, static_cast<TypeParam>(3));
    ASSERT_TRUE(this->buffer->pop(value));
    ASSERT_EQ(value, static_cast<TypeParam>(4));
    ASSERT_TRUE(this->buffer->pop(value));
    ASSERT_EQ(value, static_cast<TypeParam>(5));
    ASSERT_TRUE(this->buffer->pop(value));
    ASSERT_EQ(value, static_cast<TypeParam>(6));
    ASSERT_TRUE(this->buffer->pop(value));
    ASSERT_EQ(value, static_cast<TypeParam>(7));
    ASSERT_TRUE(this->buffer->pop(value));
    ASSERT_EQ(value, static_cast<TypeParam>(8));
    ASSERT_TRUE(this->buffer->pop(value));
    ASSERT_EQ(value, static_cast<TypeParam>(9));
    ASSERT_TRUE(this->buffer->pop(value));
    ASSERT_EQ(value, static_cast<TypeParam>(10));
    ASSERT_TRUE(this->buffer->pop(value));
    ASSERT_EQ(value, static_cast<TypeParam>(11));
    ASSERT_TRUE(this->buffer->pop(value));
    ASSERT_EQ(value, static_cast<TypeParam>(12));
    ASSERT_TRUE(this->buffer->pop(value));
    ASSERT_EQ(value, static_cast<TypeParam>(13));
    ASSERT_TRUE(this->buffer->pop(value));
    ASSERT_EQ(value, static_cast<TypeParam>(14));
    ASSERT_TRUE(this->buffer->pop(value));
    ASSERT_EQ(value, static_cast<TypeParam>(15));
    ASSERT_FALSE(this->buffer->pop(value)); // Buffer should be empty
}

TYPED_TEST(LockFreeRingBufferTest, PushPopInterleavedTest)
{
    TypeParam value;
    ASSERT_TRUE(this->buffer->push(static_cast<TypeParam>(1)));
    ASSERT_TRUE(this->buffer->push(static_cast<TypeParam>(2)));
    ASSERT_TRUE(this->buffer->pop(value));
    ASSERT_EQ(value, static_cast<TypeParam>(1));
    ASSERT_TRUE(this->buffer->push(static_cast<TypeParam>(3)));
    ASSERT_TRUE(this->buffer->pop(value));
    ASSERT_EQ(value, static_cast<TypeParam>(2));
    ASSERT_TRUE(this->buffer->pop(value));
    ASSERT_EQ(value, static_cast<TypeParam>(3));
    ASSERT_FALSE(this->buffer->pop(value)); // Buffer should be empty
}

TYPED_TEST(LockFreeRingBufferTest, OverflowTest)
{
    for (int i = 0; i < 15; ++i)
    {
        ASSERT_TRUE(this->buffer->push(static_cast<TypeParam>(i)));
    }
    ASSERT_FALSE(this->buffer->push(static_cast<TypeParam>(16))); // Buffer should be full
}

TYPED_TEST(LockFreeRingBufferTest, UnderflowTest)
{
    TypeParam value;
    ASSERT_FALSE(this->buffer->pop(value)); // Buffer should be empty
}

TYPED_TEST(LockFreeRingBufferTest, ProducerConsumerTest)
{
    std::thread producer([this]() {
        for (int i = 0; i < 100; ++i)
        {
            while (!this->buffer->push(static_cast<TypeParam>(i)))
            {
                std::this_thread::yield();
            }
        }
    });

    std::thread consumer([this]() {
        TypeParam value;
        for (int i = 0; i < 100; ++i)
        {
            while (!this->buffer->pop(value))
            {
                std::this_thread::yield();
            }
            ASSERT_EQ(value, static_cast<TypeParam>(i));
        }
    });

    producer.join();
    consumer.join();
}

TYPED_TEST(LockFreeRingBufferTest, ProducerConsumerInterleavedTest)
{
    std::thread producer([this]() {
        for (int i = 0; i < 50; ++i)
        {
            while (!this->buffer->push(static_cast<TypeParam>(i)))
            {
                std::this_thread::yield();
            }
        }
    });

    std::thread consumer([this]() {
        TypeParam value;
        for (int i = 0; i < 50; ++i)
        {
            while (!this->buffer->pop(value))
            {
                std::this_thread::yield();
            }
            ASSERT_EQ(value, static_cast<TypeParam>(i));
        }
    });

    producer.join();
    consumer.join();
}
