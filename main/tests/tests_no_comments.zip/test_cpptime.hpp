/**
 * @file test_cpptime.hpp
 * @brief Unit tests for the CppTime::Timer class using Google Test framework.
 *
 * This file contains a series of unit tests for the CppTime::Timer class. The tests are written using the Google Test
 * framework and cover various functionalities of the timer, including adding one-shot and periodic timers, removing
 * timers, and handling multiple timers.
 *
 * @note The tests use std::this_thread::sleep_for to wait for the timers to trigger. This may introduce some
 * non-determinism in the tests depending on the system's scheduling and timing accuracy.
 */

#pragma once

#include "cpptime.hpp"
#include <chrono>
#include <gtest/gtest.h>
#include <iostream>
#include <thread>

/**
 * @class TimerTest
 * @brief Test fixture for CppTime::Timer tests.
 *
 * The TimerTest class is a test fixture that provides a common setup and teardown for all the tests. It contains an
 * instance of CppTime::Timer and a boolean flag to check if the timer callback was called.
 */

class TimerTest : public ::testing::Test
{
protected:
    CppTime::Timer timer;
    bool called;

    void SetUp() override
    {
        called = false;
    }

    void TearDown() override
    {
        // Any necessary cleanup
    }
};

/**
 * @test TimerTest.AddOneshotTimer
 * @brief Tests adding a one-shot timer.
 *
 * This test adds a one-shot timer that triggers after 1 second and sets the `called` flag to true. The test then waits
 * for 2 seconds and checks if the `called` flag is true.
 */

TEST_F(TimerTest, AddOneshotTimer)
{
    auto id = timer.add(std::chrono::seconds(1), [this](CppTime::timer_id) { called = true; });

    std::this_thread::sleep_for(std::chrono::seconds(2));
    ASSERT_TRUE(called);
}

/**
 * @test TimerTest.AddPeriodicTimer
 * @brief Tests adding a periodic timer.
 *
 * This test adds a periodic timer that triggers every 500 milliseconds and increments a counter. The test waits for 2
 * seconds, removes the timer, and checks if the `called` flag is true and the counter is at least 3.
 */

TEST_F(TimerTest, AddPeriodicTimer)
{
    int call_count = 0;
    auto id = timer.add(
        std::chrono::milliseconds(500),
        [this, &call_count](CppTime::timer_id)
        {
            called = true;
            call_count++;
        },
        std::chrono::milliseconds(500));

    std::this_thread::sleep_for(std::chrono::seconds(2));
    timer.remove(id);
    ASSERT_TRUE(called);
    ASSERT_GE(call_count, 3);
}

/*
 * @test TimerTest.RemoveTimer
 * @brief Tests removing a timer.
 *
 * This test adds a one-shot timer that triggers after 1 second and sets the `called` flag to true. The test then
 * removes the timer before it triggers and waits for 2 seconds. It checks if the `called` flag is false.
 */

TEST_F(TimerTest, RemoveTimer)
{
    auto id = timer.add(std::chrono::seconds(1), [this](CppTime::timer_id) { called = true; });

    timer.remove(id);
    std::this_thread::sleep_for(std::chrono::seconds(2));
    ASSERT_FALSE(called);
}

/**
 * @test TimerTest.AddMultipleTimers
 * @brief Tests adding multiple timers.
 *
 * This test adds two one-shot timers that trigger after 1 second and 2 seconds, respectively. Each timer sets a
 * separate boolean flag to true. The test waits for 3 seconds and checks if both flags are true.
 */

TEST_F(TimerTest, AddMultipleTimers)
{
    bool called1 = false, called2 = false;

    auto id1 = timer.add(std::chrono::seconds(1), [&called1](CppTime::timer_id) { called1 = true; });

    auto id2 = timer.add(std::chrono::seconds(2), [&called2](CppTime::timer_id) { called2 = true; });

    std::this_thread::sleep_for(std::chrono::seconds(3));
    ASSERT_TRUE(called1);
    ASSERT_TRUE(called2);
}
