#include <gtest/gtest.h>

#include <vector>

#include "tools/gzip_wrapper.hpp"

class GzipWrapperTest : public ::testing::Test
{
protected:
    tools::gzip_wrapper gzip;

    void SetUp() override
    {
        // Setup code if needed
    }

    void TearDown() override
    {
        // Teardown code if needed
    }
};

TEST_F(GzipWrapperTest, PackUnpackSmallData)
{
    std::vector<std::uint8_t> original_data = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

    std::vector<std::uint8_t> packed_data = gzip.pack(original_data);
    std::vector<std::uint8_t> unpacked_data = gzip.unpack(packed_data);

    ASSERT_EQ(original_data, unpacked_data);
}

TEST_F(GzipWrapperTest, PackUnpackEmptyData)
{
    std::vector<std::uint8_t> original_data = {};

    std::vector<std::uint8_t> packed_data = gzip.pack(original_data);
    std::vector<std::uint8_t> unpacked_data = gzip.unpack(packed_data);

    ASSERT_EQ(original_data, unpacked_data);
}

TEST_F(GzipWrapperTest, PackUnpackLargeData)
{
    std::vector<std::uint8_t> original_data(1000, 0xAB); // 1000 bytes of 0xAB

    std::vector<std::uint8_t> packed_data = gzip.pack(original_data);
    std::vector<std::uint8_t> unpacked_data = gzip.unpack(packed_data);

    ASSERT_EQ(original_data, unpacked_data);
}

TEST_F(GzipWrapperTest, PackUnpackRandomData)
{
    std::vector<std::uint8_t> original_data = {0xDE, 0xAD, 0xBE, 0xEF, 0xCA, 0xFE, 0xBA, 0xBE};

    std::vector<std::uint8_t> packed_data = gzip.pack(original_data);
    std::vector<std::uint8_t> unpacked_data = gzip.unpack(packed_data);

    ASSERT_EQ(original_data, unpacked_data);
}

TEST_F(GzipWrapperTest, UnpackInvalidData)
{
    std::vector<std::uint8_t> invalid_data = {0x00, 0x01, 0x02, 0x03};

    std::vector<std::uint8_t> unpacked_data = gzip.unpack(invalid_data);

    ASSERT_TRUE(unpacked_data.empty());
}

TEST_F(GzipWrapperTest, UnpackCorruptedData)
{
    std::vector<std::uint8_t> original_data = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
    std::vector<std::uint8_t> packed_data = gzip.pack(original_data);

    // Corrupt the packed data
    packed_data[5] = 0xFF;

    std::vector<std::uint8_t> unpacked_data = gzip.unpack(packed_data);

    ASSERT_TRUE(unpacked_data.empty());
}

TEST_F(GzipWrapperTest, UnpackTruncatedData)
{
    std::vector<std::uint8_t> original_data = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
    std::vector<std::uint8_t> packed_data = gzip.pack(original_data);

    // Truncate the packed data
    packed_data.resize(packed_data.size() / 2);

    std::vector<std::uint8_t> unpacked_data = gzip.unpack(packed_data);

    ASSERT_TRUE(unpacked_data.empty());
}

TEST_F(GzipWrapperTest, UnpackDataWithInvalidCRC)
{
    std::vector<std::uint8_t> original_data = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
    std::vector<std::uint8_t> packed_data = gzip.pack(original_data);

    // Corrupt the CRC
    packed_data[packed_data.size() - 1] = 0xFF;

    std::vector<std::uint8_t> unpacked_data = gzip.unpack(packed_data);

    ASSERT_TRUE(unpacked_data.empty());
}
